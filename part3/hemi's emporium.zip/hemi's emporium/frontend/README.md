# Frontend — React SPA ⚛️

React + TypeScript + Vite frontend for Hemi's Emporium.

> In production (and in Docker), this app is **built as static files** and served directly by the NestJS backend on port 3001. The Vite dev server is only used during local development.

---

## Development

```bash
npm install
npm run dev   # Vite dev server → http://localhost:4000
```

The Vite dev server runs on port **4000**. API calls go directly to the NestJS backend at `http://localhost:3001` (which must be running separately).

---

## Building for production

```bash
npm run build   # outputs to dist/
```

The Docker multi-stage build runs this automatically. You don't need to build manually unless testing production output locally.

---

## Project Structure

```
frontend/src/
├── admin/          # Admin dashboard
├── auth/           # Password reset flow
├── cart/           # Cart page
├── chatbot/        # LLM chatbot widget
├── header/         # Navigation bar
├── items/          # Product listing + detail modal
├── login/          # Login page
├── orders/         # Order history
├── register/       # Registration page
├── store/          # Main store provider/context
├── vulnerabilities/ # Vulnerability tracker UI
├── App.tsx         # Router + layout
└── main.tsx        # Entry point
```

---

## Tech Stack

| Library | Purpose |
|---|---|
| React 19 | UI framework |
| TypeScript | Type safety |
| Vite | Build tool + dev server |
| MUI (Material UI) | Component library |
| React Router v7 | Client-side routing |
