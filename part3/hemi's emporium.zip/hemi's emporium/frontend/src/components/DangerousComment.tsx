import { useEffect, useRef, useState } from 'react'
import { Typography } from '@mui/material'
import { addDiscoveredVulnerability, isVulnerabilityDiscovered } from '../utils/vulnerabilityStorage'

type DangerousCommentProps = {
    content: string
    onXssDetected?: () => void
}

/**
 * Component that renders HTML content using refs to prevent XSS event handlers
 * from firing repeatedly on React re-renders. This is still vulnerable to XSS
 * (intentionally), and detects XSS patterns when rendering comments.
 */
function DangerousComment({ content, onXssDetected }: DangerousCommentProps) {
    const contentRef = useRef<HTMLDivElement>(null)
    const renderedContentRef = useRef<string>('')
    const [xssDetected, setXssDetected] = useState(false)

    useEffect(() => {
        // Only update innerHTML if content has changed
        if (contentRef.current && renderedContentRef.current !== content) {
            // XSS Pattern Detection - detect event-based XSS that works with dangerouslySetInnerHTML
            const xssPatterns = [
                /<img[^>]*onerror/i,
                /<img[^>]*onload/i,
                /<svg[^>]*onload/i,
                /<body[^>]*onload/i,
                /<iframe/i,
                /onerror\s*=/i,
                /onload\s*=/i,
                /onclick\s*=/i,
                /onmouseover\s*=/i,
                /onmouseenter\s*=/i,
                /onfocus\s*=/i,
                /javascript:/i,
            ];

            const isXSS = xssPatterns.some(pattern => pattern.test(content));

            // Render the potentially malicious content
            contentRef.current.innerHTML = content
            renderedContentRef.current = content

            // If XSS detected and not already discovered, award the vulnerability
            if (isXSS && !xssDetected && !isVulnerabilityDiscovered('STORED_XSS_COMMENTS')) {
                addDiscoveredVulnerability('STORED_XSS_COMMENTS')
                setXssDetected(true)
                if (onXssDetected) {
                    onXssDetected()
                }
            }
        }
    }, [content, xssDetected, onXssDetected])

    return (
        <Typography
            ref={contentRef}
            component="div"
            variant="body2"
            sx={{ color: '#cbd5e1', lineHeight: 1.6 }}
        />
    )
}

export default DangerousComment
