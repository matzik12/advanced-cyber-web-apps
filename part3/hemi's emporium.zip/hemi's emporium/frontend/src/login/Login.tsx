import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { addDiscoveredVulnerability } from '../utils/vulnerabilityStorage';
import './Login.css';
import { Box, Button, Input, InputLabel, Alert, CircularProgress } from '@mui/material';

const API_URL = 'http://localhost:3001/api';

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [vulnerabilityFound, setVulnerabilityFound] = useState<any>(null);
    const navigate = useNavigate();

    const onLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setVulnerabilityFound(null);
        setLoading(true);

        try {
            const response = await fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (data.success) {
                // Store JWT token
                localStorage.setItem('token', data.token);

                // Build user object and resolve avatar
                const userObj: any = { ...data.user };

                if (userObj.imageData) {
                    // imageData already contains a data URL
                    userObj.avatarUrl = userObj.imageData;
                } else if (userObj.imageUrl) {
                    // Try to fetch remote image and convert to data URL
                    try {
                        const resp = await fetch(userObj.imageUrl);
                        if (resp.ok) {
                            const blob = await resp.blob();
                            const reader = new FileReader();
                            const dataUrl: string = await new Promise((resolve) => {
                                reader.onload = () => resolve(reader.result as string);
                                reader.readAsDataURL(blob);
                            });
                            userObj.avatarUrl = dataUrl;
                        }
                    } catch (err) {
                        console.error('Failed to fetch remote avatar URL', err);
                    }
                }

                localStorage.setItem('user', JSON.stringify(userObj));
                // Notify other components in this tab
                try { window.dispatchEvent(new Event('userChanged')) } catch (e) { /* ignore */ }

                // Check if vulnerability was detected
                if (data.vulnerabilityDetected) {
                    // Save to localStorage
                    addDiscoveredVulnerability('SQL_INJECTION_LOGIN');
                    setVulnerabilityFound(data.vulnerabilityDetected);

                    // Show congratulations for 3 seconds before redirecting
                    setTimeout(() => {
                        navigate('/store');
                    }, 3000);
                } else {
                    // Normal login, redirect immediately
                    navigate('/store');
                }
            } else {
                setError(data.message || 'Login failed');
            }
        } catch (err) {
            setError('Failed to connect to server. Make sure the backend is running on port 3001.');
            console.error('Login error:', err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box className='login-container'>
            <Box className='form'>
                <h2 style={{ marginBottom: '15px' }}>Welcome to Hemi's Emporium</h2>

                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}

                {vulnerabilityFound && (
                    <Alert severity="success" sx={{ mb: 2 }}>
                        <strong>{vulnerabilityFound.congratulations}</strong>
                        <br />
                        {vulnerabilityFound.description}
                    </Alert>
                )}

                <InputLabel>Username:</InputLabel>
                <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={loading}
                    fullWidth
                />

                <InputLabel>Password:</InputLabel>
                <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={loading}
                    fullWidth
                    onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            onLogin(e);
                        }
                    }}
                />

                <Button
                    style={{ textAlign: 'center' }}
                    onClick={onLogin}
                    disabled={loading}
                    fullWidth
                    variant="contained"
                    sx={{ mt: 2 }}
                >
                    {loading ? <CircularProgress size={24} /> : 'Login'}
                </Button>

                <Link to={'/signup'}>Not yet registered?</Link>
                <Link style={{ fontSize: '0.85rem', color: '#94a3b8' }} to={'/reset'}>Forgot password?</Link>
            </Box>
        </Box>
    );
}

export default Login;
