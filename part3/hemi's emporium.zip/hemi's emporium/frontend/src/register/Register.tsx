import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../login/Login.css';
import { Box, Button, Input, InputLabel, Alert, CircularProgress, Typography } from '@mui/material';

const API_URL = 'http://localhost:3001/api';
const MAILHOG_URL = 'http://localhost:8025';
const EMAIL_DOMAIN = '@hemi-emporium.local';

function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const onSignup = async (e: any) => {
        e.preventDefault();
        setError('');

        // Validate email domain client-side
        if (email && !email.endsWith(EMAIL_DOMAIN)) {
            setError(`Email must be a ${EMAIL_DOMAIN} address (e.g. yourname${EMAIL_DOMAIN})`);
            return;
        }

        setLoading(true);

        try {
            const response = await fetch(`${API_URL}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    username,
                    password,
                    confirmPassword,
                    email
                }),
            });

            const data = await response.json();

            if (data.success) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                navigate('/store');
            } else {
                setError(data.message || 'Registration failed');
            }
        } catch (err) {
            setError('Failed to connect to server. Make sure the backend is running on port 3001.');
            console.error('Registration error:', err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box className='login-container'>
            <Box className='form'>
                <h2 style={{ marginBottom: '8px' }}>Create Account</h2>

                <Typography variant="body2" sx={{ mb: 2, color: '#94a3b8', fontSize: '0.8rem', lineHeight: 1.5 }}>
                    Email must be a <strong>@hemi-emporium.local</strong> address.{' '}
                    Use the{' '}
                    <a href={MAILHOG_URL} target="_blank" rel="noreferrer"
                        style={{ color: '#3b82f6' }}>
                        MailHog inbox
                    </a>
                    {' '}to receive emails (e.g. <code>yourname@hemi-emporium.local</code>).
                </Typography>

                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}

                <InputLabel>Username:</InputLabel>
                <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={loading}
                    fullWidth
                />

                <InputLabel sx={{ mt: 1 }}>Email (@hemi-emporium.local):</InputLabel>
                <Input
                    type="text"
                    placeholder={`yourname${EMAIL_DOMAIN}`}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={loading}
                    fullWidth
                />

                <InputLabel sx={{ mt: 1 }}>Password:</InputLabel>
                <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={loading}
                    fullWidth
                />

                <InputLabel sx={{ mt: 1 }}>Confirm Password:</InputLabel>
                <Input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    disabled={loading}
                    fullWidth
                    onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            onSignup(e);
                        }
                    }}
                />

                <Button
                    style={{ textAlign: 'center' }}
                    onClick={onSignup}
                    disabled={loading}
                    fullWidth
                    variant="contained"
                    sx={{ mt: 2 }}
                >
                    {loading ? <CircularProgress size={24} /> : 'Sign up'}
                </Button>

                <Link to={'/'}>Already have a user?</Link>
            </Box>
        </Box>
    );
}

export default Register;
