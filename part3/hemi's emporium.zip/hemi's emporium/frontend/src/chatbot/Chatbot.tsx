import { useState, useRef, useEffect } from 'react'
import { Box, Typography, TextField, IconButton, Paper, CircularProgress, Fab, Snackbar, Alert } from '@mui/material'
import SendIcon from '@mui/icons-material/Send'
import CloseIcon from '@mui/icons-material/Close'
import SmartToyIcon from '@mui/icons-material/SmartToy'
import { addDiscoveredVulnerability } from '../utils/vulnerabilityStorage'

const API_URL = 'http://localhost:3001/api'
const SECRET_PHRASE = 'ADMIN-SECRET-2024'

type Message = {
    role: 'user' | 'assistant'
    content: string
}

function Chatbot() {
    const [open, setOpen] = useState(false)
    const [messages, setMessages] = useState<Message[]>([])
    const [input, setInput] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [llmAlert, setLlmAlert] = useState(false)
    const bottomRef = useRef<HTMLDivElement | null>(null)

    useEffect(() => {
        if (open && messages.length === 0) {
            setMessages([{
                role: 'assistant',
                content: "Hi! I'm the Hemi's Emporium assistant 🛒 Ask me anything about our products or your orders!",
            }])
        }
    }, [open])

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, [messages, loading])

    const sendMessage = async () => {
        const text = input.trim()
        if (!text || loading) return

        const userMsg: Message = { role: 'user', content: text }
        const newMessages = [...messages, userMsg]
        setMessages(newMessages)
        setInput('')
        setLoading(true)
        setError(null)

        try {
            // Pass full history so the model has context (history is not sanitized - LLM vulnerability)
            const history = newMessages.slice(0, -1) // all except the one we just added
            const response = await fetch(`${API_URL}/chatbot`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text, history }),
            })

            const data = await response.json()
            if (data.success) {
                const reply: string = data.reply
                setMessages(prev => [...prev, { role: 'assistant', content: reply }])

                // Detect if the LLM was tricked into revealing the secret (LLM01 - Prompt Injection)
                if (reply.includes(SECRET_PHRASE)) {
                    addDiscoveredVulnerability('LLM_PROMPT_INJECTION')
                    setLlmAlert(true)
                }
            } else {
                setError(data.message || 'The assistant is unavailable right now.')
            }
        } catch {
            setError('Could not reach the assistant. Is the server running?')
        } finally {
            setLoading(false)
        }
    }

    return (
        <>
            {/* LLM vulnerability discovered alert */}
            <Snackbar
                open={llmAlert}
                autoHideDuration={10000}
                onClose={() => setLlmAlert(false)}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert severity="success" onClose={() => setLlmAlert(false)} sx={{ width: '100%' }}>
                    <Typography variant="subtitle2" fontWeight={700}>🎉 LLM01: Prompt Injection Discovered!</Typography>
                    <Typography variant="body2">You tricked the AI into revealing its confidential system prompt secret. This is a real-world LLM vulnerability (OWASP LLM Top 10 - LLM01).</Typography>
                </Alert>
            </Snackbar>

            {/* Floating action button */}
            <Fab
                onClick={() => setOpen(prev => !prev)}
                sx={{
                    position: 'fixed',
                    bottom: 28,
                    right: 28,
                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                    color: '#fff',
                    boxShadow: '0 8px 32px rgba(59,130,246,0.45)',
                    '&:hover': {
                        background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
                        transform: 'scale(1.08)',
                    },
                    transition: 'all 0.25s ease',
                    zIndex: 1300,
                }}
                aria-label="Open AI assistant"
            >
                {open ? <CloseIcon /> : <SmartToyIcon />}
            </Fab>

            {/* Chat window */}
            {open && (
                <Paper
                    elevation={16}
                    sx={{
                        position: 'fixed',
                        bottom: 96,
                        right: 28,
                        width: 370,
                        maxHeight: 520,
                        display: 'flex',
                        flexDirection: 'column',
                        bgcolor: 'rgba(15, 23, 42, 0.97)',
                        backdropFilter: 'blur(12px)',
                        border: '1px solid rgba(59, 130, 246, 0.25)',
                        borderRadius: 3,
                        overflow: 'hidden',
                        zIndex: 1299,
                        boxShadow: '0 24px 80px rgba(0,0,0,0.6)',
                    }}
                >
                    {/* Header */}
                    <Box sx={{
                        p: 2,
                        background: 'linear-gradient(135deg, #1e3a5f 0%, #312e81 100%)',
                        borderBottom: '1px solid rgba(59,130,246,0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1.5,
                    }}>
                        <SmartToyIcon sx={{ color: '#93c5fd', fontSize: 22 }} />
                        <Box>
                            <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#f1f5f9', lineHeight: 1.1 }}>
                                Store Assistant
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#7dd3fc', fontSize: 11 }}>
                                Powered by Qwen2
                            </Typography>
                        </Box>
                        <IconButton size="small" onClick={() => setOpen(false)} sx={{ ml: 'auto', color: '#94a3b8' }}>
                            <CloseIcon fontSize="small" />
                        </IconButton>
                    </Box>

                    {/* Messages */}
                    <Box sx={{
                        flex: 1,
                        overflowY: 'auto',
                        p: 1.5,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 1,
                        '&::-webkit-scrollbar': { width: 4 },
                        '&::-webkit-scrollbar-thumb': { bgcolor: 'rgba(59,130,246,0.3)', borderRadius: 2 },
                    }}>
                        {messages.map((msg, i) => (
                            <Box
                                key={i}
                                sx={{
                                    display: 'flex',
                                    justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                                }}
                            >
                                <Box sx={{
                                    maxWidth: '82%',
                                    px: 1.5,
                                    py: 1,
                                    borderRadius: msg.role === 'user' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                                    background: msg.role === 'user'
                                        ? 'linear-gradient(135deg, #3b82f6, #6366f1)'
                                        : 'rgba(30, 41, 59, 0.8)',
                                    border: msg.role === 'assistant' ? '1px solid rgba(59,130,246,0.15)' : 'none',
                                }}>
                                    <Typography variant="body2" sx={{ color: '#f1f5f9', whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>
                                        {msg.content}
                                    </Typography>
                                </Box>
                            </Box>
                        ))}

                        {loading && (
                            <Box sx={{ display: 'flex', justifyContent: 'flex-start' }}>
                                <Box sx={{
                                    px: 2, py: 1.2,
                                    borderRadius: '16px 16px 16px 4px',
                                    bgcolor: 'rgba(30, 41, 59, 0.8)',
                                    border: '1px solid rgba(59,130,246,0.15)',
                                    display: 'flex', gap: 0.8, alignItems: 'center',
                                }}>
                                    {[0, 150, 300].map(delay => (
                                        <Box key={delay} sx={{
                                            width: 7, height: 7, borderRadius: '50%',
                                            bgcolor: '#3b82f6',
                                            animation: 'bounce 1s infinite',
                                            animationDelay: `${delay}ms`,
                                            '@keyframes bounce': {
                                                '0%, 100%': { transform: 'translateY(0)' },
                                                '50%': { transform: 'translateY(-5px)' },
                                            },
                                        }} />
                                    ))}
                                </Box>
                            </Box>
                        )}

                        {error && (
                            <Typography variant="caption" sx={{ color: '#f87171', textAlign: 'center', px: 1 }}>
                                ⚠️ {error}
                            </Typography>
                        )}

                        <div ref={bottomRef} />
                    </Box>

                    {/* Input */}
                    <Box sx={{
                        p: 1.5,
                        borderTop: '1px solid rgba(59,130,246,0.15)',
                        display: 'flex',
                        gap: 1,
                        alignItems: 'flex-end',
                    }}>
                        <TextField
                            fullWidth
                            multiline
                            maxRows={3}
                            placeholder="Ask me anything..."
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyDown={e => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault()
                                    sendMessage()
                                }
                            }}
                            size="small"
                            sx={{
                                '& .MuiOutlinedInput-root': {
                                    bgcolor: 'rgba(30,41,59,0.6)',
                                    '& fieldset': { borderColor: 'rgba(59,130,246,0.25)' },
                                    '&:hover fieldset': { borderColor: 'rgba(59,130,246,0.5)' },
                                    '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                    borderRadius: 2,
                                },
                                '& textarea': { color: '#f1f5f9', fontSize: 14 },
                                '& .MuiInputBase-input::placeholder': { color: '#64748b' },
                            }}
                        />
                        <IconButton
                            onClick={sendMessage}
                            disabled={!input.trim() || loading}
                            sx={{
                                background: input.trim() && !loading
                                    ? 'linear-gradient(135deg, #3b82f6, #8b5cf6)'
                                    : 'rgba(59,130,246,0.15)',
                                color: '#fff',
                                borderRadius: 2,
                                p: 1.2,
                                transition: 'all 0.2s ease',
                                '&:hover': { transform: 'scale(1.08)' },
                                '&:disabled': { color: '#475569' },
                            }}
                        >
                            {loading ? <CircularProgress size={18} sx={{ color: '#3b82f6' }} /> : <SendIcon fontSize="small" />}
                        </IconButton>
                    </Box>
                </Paper>
            )}
        </>
    )
}

export default Chatbot
