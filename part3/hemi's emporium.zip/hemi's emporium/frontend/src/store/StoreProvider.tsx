import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import { addDiscoveredVulnerability } from '../utils/vulnerabilityStorage'

const API_URL = 'http://localhost:3001/api';

export type Item = {
    id: string
    name: string
    price: number
    description?: string
    stock?: number
}

export type CartItem = {
    id: string
    productId: string
    quantity: number
    product: Item
}

type StoreContextType = {
    items: Item[]
    cart: Record<string, number>
    cartItems: CartItem[]
    loading: boolean
    balance: number
    addToCart: (id: string) => Promise<void>
    removeFromCart: (id: string) => Promise<void>
    clearCart: () => Promise<void>
    checkout: () => Promise<any>
    fetchBalance: () => Promise<void>
    addFunds: (amount: number) => Promise<void>
    fetchProducts: () => Promise<void>
}

const StoreContext = createContext<StoreContextType | undefined>(undefined)

export function StoreProvider({ children }: { children: ReactNode }) {
    const [items, setItems] = useState<Item[]>([])
    const [cart, setCart] = useState<Record<string, number>>({})
    const [cartItems, setCartItems] = useState<CartItem[]>([])
    const [loading, setLoading] = useState(true)
    const [balance, setBalance] = useState(0)

    // Fetch products from backend
    useEffect(() => {
        fetchProducts()
        fetchBalance()
    }, [])

    // Fetch cart from backend
    useEffect(() => {
        fetchCart()
    }, [])

    const fetchProducts = async () => {
        try {
            const response = await fetch(`${API_URL}/products`)
            const data = await response.json()
            if (data.success) {
                // We are smart devlepopers and do not want user to see alk the data of all products! we map it nere! smart!
                setItems(currentItems => {
                    const newProductIds = new Set(data.products.map((p: Item) => p.id));
                    const hasDeletedProduct = currentItems.some(item => !newProductIds.has(item.id));

                    if (hasDeletedProduct) {
                        addDiscoveredVulnerability('INSECURE_PRODUCT_DELETION');
                    }

                    return data.products;
                })
            }
        } catch (error) {
            console.error('Failed to fetch products:', error)
        } finally {
            setLoading(false)
        }
    }

    const fetchCart = async () => {
        try {
            const token = localStorage.getItem('token')
            if (!token) return

            const response = await fetch(`${API_URL}/cart`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })
            const data = await response.json()
            if (data.success && data.cart) {
                setCartItems(data.cart)
                // Convert to Record format for compatibility
                const cartRecord: Record<string, number> = {}
                data.cart.forEach((item: CartItem) => {
                    cartRecord[item.productId] = item.quantity
                })
                setCart(cartRecord)
            }
        } catch (error) {
            console.error('Failed to fetch cart:', error)
        }
    }

    const addToCart = async (id: string) => {
        try {
            const token = localStorage.getItem('token')
            if (!token) {
                console.error('Not authenticated')
                return
            }

            const response = await fetch(`${API_URL}/cart`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId: id, quantity: 1 }),
            })

            const data = await response.json()
            if (data.success) {
                // Refresh cart from backend
                await fetchCart()
            }
        } catch (error) {
            console.error('Failed to add to cart:', error)
        }
    }

    const removeFromCart = async (id: string) => {
        try {
            const token = localStorage.getItem('token')
            if (!token) {
                console.error('Not authenticated')
                return
            }

            const response = await fetch(`${API_URL}/cart/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })

            const data = await response.json()
            if (data.success) {
                // Refresh cart from backend
                await fetchCart()
            }
        } catch (error) {
            console.error('Failed to remove from cart:', error)
        }
    }

    const clearCart = async () => {
        try {
            const token = localStorage.getItem('token')
            if (!token) {
                console.error('Not authenticated')
                return
            }

            const response = await fetch(`${API_URL}/cart`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })

            const data = await response.json()
            if (data.success) {
                setCart({})
                setCartItems([])
            }
        } catch (error) {
            console.error('Failed to clear cart:', error)
        }
    }

    const fetchBalance = async () => {
        try {
            const token = localStorage.getItem('token')
            if (!token) return

            const response = await fetch(`${API_URL}/wallet`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })
            const data = await response.json()
            if (data.success) {
                setBalance(Number(data.balance) || 0)
            }
        } catch (error) {
            console.error('Failed to fetch balance:', error)
        }
    }

    const addFunds = async (amount: number) => {
        try {
            const token = localStorage.getItem('token')
            if (!token) {
                console.error('Not authenticated')
                return
            }

            const response = await fetch(`${API_URL}/wallet/add-funds`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ amount }),
            })

            const data = await response.json()
            if (data.success) {
                setBalance(Number(data.balance) || 0)
            }
        } catch (error) {
            console.error('Failed to add funds:', error)
        }
    }

    const checkout = async () => {
        try {
            const token = localStorage.getItem('token')
            if (!token) {
                console.error('Not authenticated')
                return { success: false, message: 'Not authenticated' }
            }

            const response = await fetch(`${API_URL}/cart/checkout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })

            const data = await response.json()
            if (data.success) {
                setBalance(Number(data.newBalance) || 0)
                setCart({})
                setCartItems([])
            }
            return data
        } catch (error) {
            console.error('Failed to checkout:', error)
            return { success: false, message: 'Checkout failed' }
        }
    }

    return (
        <StoreContext.Provider value={{ items, cart, cartItems, loading, balance, addToCart, removeFromCart, clearCart, checkout, fetchBalance, addFunds, fetchProducts }}>
            {children}
        </StoreContext.Provider>
    )
}

export function useStore() {
    const ctx = useContext(StoreContext)
    if (!ctx) throw new Error('useStore must be used within StoreProvider')
    return ctx
}

export default StoreProvider
