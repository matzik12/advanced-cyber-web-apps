import { Box, Container } from '@mui/material'
import Items from '../items/Items'
import Header from '../header/Header'

function Store() {
    return (
        <Box sx={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            bgcolor: '#0f172a',
            background: 'linear-gradient(135deg, #0f172a 0%, #1a2332 100%)'
        }}>
            <Header />
            <Container component="main" sx={{ flex: 1, py: 3 }}>
                <Items />
            </Container>
        </Box>
    )
}

export default Store;
