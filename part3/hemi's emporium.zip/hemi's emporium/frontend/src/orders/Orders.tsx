import { useState, useEffect } from 'react'
import { Box, Typography, CircularProgress, Card, CardContent, Accordion, AccordionSummary, AccordionDetails, Alert } from '@mui/material'
import Header from '../header/Header'
import './Orders.css'
import { addDiscoveredVulnerability } from '../utils/vulnerabilityStorage'

const API_URL = 'http://localhost:3001/api'

type OrderItem = {
    id: string
    productId: string
    quantity: number
    price: number
}

type Order = {
    id: string
    userId: string
    total: number
    createdAt: string
    items?: OrderItem[]
}

function Orders() {
    const [orders, setOrders] = useState<Order[]>([])
    const [loading, setLoading] = useState(true)
    const [expandedOrder, setExpandedOrder] = useState<string | null>(null)
    const [vulnAlert, setVulnAlert] = useState<{ name: string; description: string } | null>(null)

    useEffect(() => {
        fetchOrders()
    }, [])

    const fetchOrders = async () => {
        try {
            const token = localStorage.getItem('token')
            const userId = JSON.parse(localStorage.getItem('user') || '{}').id // vulnerability: IDOR
            if (!userId) return
            if (!token) return

            const response = await fetch(`${API_URL}/orders`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId }),
            })
            const data = await response.json()
            if (data.success) {
                for (const order of data.orders) {
                    if (userId !== order.userId) {
                        addDiscoveredVulnerability("IDOR_ORDERS")
                        setVulnAlert({
                            name: 'IDOR Vulnerability',
                            description: 'You successfully exploited an IDOR vulnerability by accessing another user\'s orders!',
                        })
                        setTimeout(() => {
                            setVulnAlert(null)
                        }, 8000)
                        break;
                    }
                }
                setOrders(data.orders || [])
            }
        } catch (error) {
            console.error('Failed to fetch orders:', error)
        } finally {
            setLoading(false)
        }
    }

    const fetchOrderItems = async (orderId: string) => {
        try {
            const token = localStorage.getItem('token')
            if (!token) return

            const response = await fetch(`${API_URL}/orders/${orderId}/items`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })
            const data = await response.json()
            if (data.success) {
                // Update the order with items
                setOrders(prev => prev.map(order =>
                    order.id === orderId ? { ...order, items: data.items } : order
                ))
            }
        } catch (error) {
            console.error('Failed to fetch order items:', error)
        }
    }

    const handleAccordionChange = (orderId: string) => {
        if (expandedOrder === orderId) {
            setExpandedOrder(null)
        } else {
            setExpandedOrder(orderId)
            const order = orders.find(o => o.id === orderId)
            if (order && !order.items) {
                fetchOrderItems(orderId)
            }
        }
    }

    if (loading) {
        return (
            <>
                <Header />
                <Box sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    minHeight: 'calc(100vh - 64px)',
                    bgcolor: '#0f172a'
                }}>
                    <CircularProgress />
                </Box>
            </>
        )
    }

    return (
        <>
            <Header />
            <Box sx={{
                p: 4,
                maxWidth: 1200,
                mx: 'auto',
                minHeight: 'calc(100vh - 64px)',
                bgcolor: '#0f172a'
            }}>
                <Typography variant="h4" gutterBottom sx={{
                    mb: 4,
                    fontWeight: 700,
                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                }}>
                    📦 Order History
                </Typography>

                {/* Vulnerability Alert */}
                {vulnAlert && (
                    <Alert severity="success" sx={{ mb: 2 }} onClose={() => setVulnAlert(null)}>
                        <Typography variant="subtitle2" fontWeight={600}>
                            {vulnAlert.name}
                        </Typography>
                        <Typography variant="body2">
                            {vulnAlert.description}
                        </Typography>
                    </Alert>
                )}

                {orders.length === 0 && (
                    <Card sx={{
                        textAlign: 'center',
                        py: 6,
                        bgcolor: 'rgba(30, 41, 59, 0.5)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(59, 130, 246, 0.1)',
                        borderRadius: 3,
                    }}>
                        <CardContent>
                            <Typography variant="h6" sx={{ color: '#94a3b8' }}>
                                No orders yet
                            </Typography>
                            <Typography variant="body2" sx={{ mt: 1, color: '#64748b' }}>
                                Start shopping to see your order history!
                            </Typography>
                        </CardContent>
                    </Card>
                )}

                {orders.map((order) => (
                    <Accordion
                        key={order.id}
                        expanded={expandedOrder === order.id}
                        onChange={() => handleAccordionChange(order.id)}
                        sx={{
                            mb: 2,
                            bgcolor: 'rgba(30, 41, 59, 0.5)',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(59, 130, 246, 0.1)',
                            borderRadius: 2,
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                            '&:before': {
                                display: 'none',
                            },
                            transition: 'all 0.3s ease',
                            '&:hover': {
                                borderColor: 'rgba(59, 130, 246, 0.3)',
                                boxShadow: '0 6px 20px rgba(59, 130, 246, 0.2)',
                            }
                        }}
                    >
                        <AccordionSummary sx={{
                            '& .MuiAccordionSummary-content': {
                                my: 2,
                            }
                        }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center', pr: 2 }}>
                                <Box>
                                    <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#f1f5f9' }}>
                                        Order #{order.id.slice(0, 8)}
                                    </Typography>
                                    <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                                        {new Date(order.createdAt).toLocaleDateString('en-US', {
                                            year: 'numeric',
                                            month: 'long',
                                            day: 'numeric',
                                            hour: '2-digit',
                                            minute: '2-digit'
                                        })}
                                    </Typography>
                                </Box>
                                <Typography variant="h6" sx={{
                                    fontWeight: 700,
                                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                                    WebkitBackgroundClip: 'text',
                                    WebkitTextFillColor: 'transparent',
                                }}>
                                    ${Number(order.total).toFixed(2)}
                                </Typography>
                            </Box>
                        </AccordionSummary>
                        <AccordionDetails sx={{
                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                            borderTop: '1px solid rgba(59, 130, 246, 0.1)'
                        }}>
                            {!order.items ? (
                                <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
                                    <CircularProgress size={24} />
                                </Box>
                            ) : order.items.length === 0 ? (
                                <Typography sx={{ color: '#94a3b8' }}>No items found</Typography>
                            ) : (
                                <Box>
                                    {order.items.map((item, index) => (
                                        <Box
                                            key={item.id}
                                            sx={{
                                                display: 'flex',
                                                justifyContent: 'space-between',
                                                py: 1.5,
                                                borderBottom: index < order.items!.length - 1 ? '1px solid rgba(59, 130, 246, 0.1)' : 'none'
                                            }}
                                        >
                                            <Box>
                                                <Typography variant="body1" sx={{ color: '#f1f5f9', fontWeight: 500 }}>
                                                    Product ID: {item.productId.slice(0, 8)}
                                                </Typography>
                                                <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                                                    Quantity: {item.quantity}
                                                </Typography>
                                            </Box>
                                            <Typography variant="body1" sx={{
                                                fontWeight: 600,
                                                color: '#3b82f6'
                                            }}>
                                                ${(Number(item.price) * item.quantity).toFixed(2)}
                                            </Typography>
                                        </Box>
                                    ))}
                                </Box>
                            )}
                        </AccordionDetails>
                    </Accordion>
                ))}
            </Box>
        </>
    )
}

export default Orders
