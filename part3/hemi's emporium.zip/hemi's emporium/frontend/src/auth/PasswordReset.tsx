import { useState } from 'react'
import { Box, Typography, TextField, Button, Alert, Paper, Stepper, Step, StepLabel, Divider, Link } from '@mui/material'
import LockResetIcon from '@mui/icons-material/LockReset'
import { useNavigate } from 'react-router-dom'
import { addDiscoveredVulnerability } from '../utils/vulnerabilityStorage'

const API_URL = 'http://localhost:3001/api'

function PasswordReset() {
    const navigate = useNavigate()
    const [activeStep, setActiveStep] = useState(0)

    // Step 0 — request reset
    const [email, setEmail] = useState('')
    const [reqLoading, setReqLoading] = useState(false)
    const [reqMsg, setReqMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

    // Step 1 — use token
    const [token, setToken] = useState('')
    const [newPassword, setNewPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [resetLoading, setResetLoading] = useState(false)
    const [resetMsg, setResetMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
    const [tokenReuseDetected, setTokenReuseDetected] = useState(false)
    const [isAdminReset, setIsAdminReset] = useState(false)
    const [done, setDone] = useState(false)

    const requestReset = async () => {
        if (!email.trim()) return
        setReqLoading(true)
        setReqMsg(null)
        try {
            const res = await fetch(`${API_URL}/auth/reset-request`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email }),
            })
            const data = await res.json()
            if (data.success) {
                setReqMsg({ type: 'success', text: data.message })
                setActiveStep(1)
            } else {
                setReqMsg({ type: 'error', text: data.message })
            }
        } catch {
            setReqMsg({ type: 'error', text: 'Network error. Please try again.' })
        } finally {
            setReqLoading(false)
        }
    }

    const doReset = async () => {
        if (!token.trim() || !newPassword) return
        if (newPassword !== confirmPassword) {
            setResetMsg({ type: 'error', text: 'Passwords do not match.' })
            return
        }
        setResetLoading(true)
        setResetMsg(null)
        try {
            const res = await fetch(`${API_URL}/auth/reset-password`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token, newPassword }),
            })
            const data = await res.json()

            if (data.success) {
                setDone(true)
                setResetMsg({ type: 'success', text: 'Your password has been reset successfully.' })

                // VULNERABILITY (token reuse): backend tells us the token was already used before
                if (data.tokenWasPreviouslyUsed) {
                    setTokenReuseDetected(true)
                    addDiscoveredVulnerability('PASSWORD_RESET_TOKEN_REUSE')
                }

                // VULNERABILITY — Weak/predictable token: only triggered when the admin's password is reset
                if (data.isAdminReset) {
                    setIsAdminReset(true)
                    addDiscoveredVulnerability('WEAK_RESET_TOKEN')
                }
            } else {
                setResetMsg({ type: 'error', text: data.message || 'Invalid or expired token.' })
            }
        } catch {
            setResetMsg({ type: 'error', text: 'Network error. Please try again.' })
        } finally {
            setResetLoading(false)
        }
    }

    const inputSx = {
        mb: 2,
        '& .MuiOutlinedInput-root': {
            bgcolor: 'rgba(30,41,59,0.6)',
            '& fieldset': { borderColor: 'rgba(59,130,246,0.25)' },
            '&:hover fieldset': { borderColor: 'rgba(59,130,246,0.5)' },
            '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
        },
        '& input': { color: '#f1f5f9' },
        '& label': { color: '#64748b' },
        '& label.Mui-focused': { color: '#3b82f6' },
    }

    return (
        <Box sx={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: '#0f172a',
            p: 2,
        }}>
            <Paper elevation={12} sx={{
                p: { xs: 3, sm: 4 },
                width: '100%',
                maxWidth: 460,
                bgcolor: 'rgba(15,23,42,0.98)',
                border: '1px solid rgba(59,130,246,0.2)',
                borderRadius: 3,
                boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
            }}>
                {/* Header */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
                    <LockResetIcon sx={{ color: '#3b82f6', fontSize: 32 }} />
                    <Box>
                        <Typography variant="h6" sx={{ fontWeight: 700, color: '#f1f5f9', lineHeight: 1.1 }}>
                            Reset your password
                        </Typography>
                        <Typography variant="caption" sx={{ color: '#64748b' }}>
                            Hemi's Emporium
                        </Typography>
                    </Box>
                </Box>

                <Stepper activeStep={activeStep} sx={{
                    mb: 3,
                    '& .MuiStepLabel-label': { color: '#64748b' },
                    '& .MuiStepLabel-label.Mui-active': { color: '#f1f5f9' },
                    '& .MuiStepLabel-label.Mui-completed': { color: '#10b981' },
                    '& .MuiStepIcon-root': { color: 'rgba(59,130,246,0.3)' },
                    '& .MuiStepIcon-root.Mui-active': { color: '#3b82f6' },
                    '& .MuiStepIcon-root.Mui-completed': { color: '#10b981' },
                }}>
                    <Step><StepLabel>Request token</StepLabel></Step>
                    <Step><StepLabel>Set new password</StepLabel></Step>
                </Stepper>

                <Divider sx={{ mb: 3, borderColor: 'rgba(59,130,246,0.1)' }} />

                {/* Step 0 — email form */}
                {activeStep === 0 && (
                    <>
                        <Typography variant="body2" sx={{ color: '#94a3b8', mb: 2 }}>
                            Enter the email address associated with your account and we'll send you a reset token.
                        </Typography>
                        <TextField
                            fullWidth label="Email address" type="email"
                            value={email} onChange={e => setEmail(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && requestReset()}
                            sx={inputSx}
                        />
                        {reqMsg && <Alert severity={reqMsg.type} sx={{ mb: 2 }}>{reqMsg.text}</Alert>}
                        <Button fullWidth variant="contained" onClick={requestReset} disabled={reqLoading}
                            sx={{
                                py: 1.2, background: 'linear-gradient(135deg,#3b82f6,#6366f1)',
                                '&:hover': { background: 'linear-gradient(135deg,#2563eb,#4f46e5)' }
                            }}>
                            {reqLoading ? 'Sending…' : 'Send reset token'}
                        </Button>
                    </>
                )}

                {/* Step 1 — token + new password */}
                {activeStep === 1 && !done && (
                    <>
                        <Typography variant="body2" sx={{ color: '#94a3b8', mb: 2 }}>
                            Enter the token from your email and choose a new password.
                        </Typography>
                        <TextField
                            fullWidth label="Reset token"
                            value={token} onChange={e => setToken(e.target.value)}
                            sx={inputSx}
                        />
                        <TextField
                            fullWidth label="New password" type="password"
                            value={newPassword} onChange={e => setNewPassword(e.target.value)}
                            sx={inputSx}
                        />
                        <TextField
                            fullWidth label="Confirm new password" type="password"
                            value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && doReset()}
                            sx={inputSx}
                        />
                        {resetMsg && <Alert severity={resetMsg.type} sx={{ mb: 2 }}>{resetMsg.text}</Alert>}
                        <Button fullWidth variant="contained" onClick={doReset} disabled={resetLoading}
                            sx={{
                                py: 1.2, mb: 1.5, background: 'linear-gradient(135deg,#10b981,#059669)',
                                '&:hover': { background: 'linear-gradient(135deg,#059669,#047857)' }
                            }}>
                            {resetLoading ? 'Resetting…' : 'Reset password'}
                        </Button>
                        <Button fullWidth variant="text" onClick={() => setActiveStep(0)}
                            sx={{ color: '#64748b', '&:hover': { color: '#94a3b8' } }}>
                            ← Back
                        </Button>
                    </>
                )}

                {/* Success state */}
                {done && (
                    <>
                        <Alert severity="success" sx={{ mb: 2 }}>
                            Your password has been reset successfully.
                        </Alert>
                        {tokenReuseDetected && (
                            <Alert severity="warning" sx={{ mb: 2 }}>
                                <strong>🎉 Vulnerability discovered: Token Reuse!</strong>
                                <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                                    The reset token was already used before, but the server accepted it again — it was never invalidated after first use.
                                </Typography>
                            </Alert>
                        )}
                        {isAdminReset && (
                            <Alert severity="warning" sx={{ mb: 2 }}>
                                <strong>🎉 Vulnerability discovered: Weak Reset Token!</strong>
                                <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                                    You reset the admin's password using a brute-forced token. The token was timestamp-based with only 100 possible random suffixes — trivially guessable.
                                </Typography>
                            </Alert>
                        )}
                        <Button fullWidth variant="contained" onClick={() => navigate('/')}
                            sx={{
                                background: 'linear-gradient(135deg,#3b82f6,#6366f1)',
                                '&:hover': { background: 'linear-gradient(135deg,#2563eb,#4f46e5)' }
                            }}>
                            Back to login
                        </Button>
                    </>
                )}

                <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', mt: 2, color: '#475569' }}>
                    Remember your password?{' '}
                    <Link onClick={() => navigate('/')} sx={{ color: '#3b82f6', cursor: 'pointer' }}>
                        Sign in
                    </Link>
                </Typography>
            </Paper>
        </Box>
    )
}

export default PasswordReset
