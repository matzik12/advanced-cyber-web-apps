import ItemCard from './ItemCard'
import './Items.css'
import { Box, CircularProgress, Typography } from '@mui/material'
import { useStore } from '../store/StoreProvider'
import { useEffect } from 'react'

function Items() {
    const { items, loading, fetchProducts } = useStore()

    useEffect(() => {
        fetchProducts()
    }, [])

    // Refetch products when page becomes visible (e.g., navigating back from admin)
    useEffect(() => {
        const handleVisibilityChange = () => {
            if (document.visibilityState === 'visible') {
                fetchProducts()
            }
        }

        document.addEventListener('visibilitychange', handleVisibilityChange)

        // Also refetch when window regains focus
        const handleFocus = () => {
            fetchProducts()
        }

        window.addEventListener('focus', handleFocus)

        return () => {
            document.removeEventListener('visibilitychange', handleVisibilityChange)
            window.removeEventListener('focus', handleFocus)
        }
    }, [])

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '50vh' }}>
                <CircularProgress />
            </Box>
        )
    }

    if (items.length === 0) {
        return (
            <Box sx={{ textAlign: 'center', py: 8, color: '#94a3b8' }}>
                <Typography variant="h6">No products available</Typography>
                <Typography variant="body2">Check back later!</Typography>
            </Box>
        )
    }

    return (
        <Box className="items-grid">
            {items.map((item) => (
                <div key={item.id} className="item-card">
                    <ItemCard
                        id={item.id}
                        name={item.name}
                        price={item.price}
                        description={item.description}
                        stock={item.stock}
                    />
                </div>
            ))}
        </Box>
    )
}

export default Items
