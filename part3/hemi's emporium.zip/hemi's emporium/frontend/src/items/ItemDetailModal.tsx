import { useState, useEffect } from 'react'
import { Modal, Box, Typography, Button, Chip, TextField, Divider, Alert, CircularProgress } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart'
import CommentIcon from '@mui/icons-material/Comment'
import SendIcon from '@mui/icons-material/Send'
import type { Item } from '../store/StoreProvider'
import DangerousComment from '../components/DangerousComment'

const API_URL = 'http://localhost:3001/api'

type Comment = {
    id: string
    productId: string
    userId: string
    username: string
    content: string
    createdAt: string
}

type ItemDetailModalProps = {
    item: Item | null
    open: boolean
    onClose: () => void
    onAddToCart: (id: string) => void
}

function ItemDetailModal({ item, open, onClose, onAddToCart }: ItemDetailModalProps) {
    const [comments, setComments] = useState<Comment[]>([])
    const [newComment, setNewComment] = useState('')
    const [loading, setLoading] = useState(false)
    const [vulnAlert, setVulnAlert] = useState<{ name: string; description: string } | null>(null)
    const [fullItem, setFullItem] = useState<Item | null>(null)

    useEffect(() => {
        if (item && open) {
            setFullItem(null)
            fetchFullItem()
            fetchComments()
        }
    }, [item, open])

    const fetchFullItem = async () => {
        if (!item) return

        try {
            const response = await fetch(`${API_URL}/products/${item.id}`)
            const data = await response.json()
            if (data.success) {
                setFullItem(data.product)
            }
        } catch (error) {
            console.error('Failed to fetch product details:', error)
        }
    }

    const fetchComments = async () => {
        if (!item) return

        try {
            const response = await fetch(`${API_URL}/comments/${item.id}`)
            const data = await response.json()
            if (data.success) {
                setComments(data.comments || [])
            }
        } catch (error) {
            console.error('Failed to fetch comments:', error)
        }
    }

    const handleSubmitComment = async () => {
        if (!newComment.trim() || !item) return

        setLoading(true)

        try {
            const token = localStorage.getItem('token')
            if (!token) {
                alert('Please log in to comment')
                setLoading(false)
                return
            }

            const response = await fetch(`${API_URL}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({
                    productId: item.id,
                    content: newComment,
                }),
            })

            const data = await response.json()
            if (data.success) {
                setNewComment('')
                await fetchComments()
            } else {
                alert(data.message || 'Failed to add comment')
            }
        } catch (error) {
            console.error('Failed to submit comment:', error)
            alert('Failed to add comment')
        } finally {
            setLoading(false)
        }
    }

    const handleXssDetected = () => {
        // Show success alert when XSS is detected
        setVulnAlert({
            name: 'Stored XSS',
            description: 'You successfully exploited a Stored XSS vulnerability by executing malicious code!',
        })

        // Auto-hide after 8 seconds
        setTimeout(() => {
            setVulnAlert(null)
        }, 8000)
    }

    if (!item) return null

    return (
        <Modal
            open={open}
            onClose={onClose}
            sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'auto',
            }}
        >
            <Box sx={{
                bgcolor: 'rgba(30, 41, 59, 0.98)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(59, 130, 246, 0.2)',
                borderRadius: 3,
                p: 4,
                maxWidth: 700,
                width: '90%',
                maxHeight: '90vh',
                overflowY: 'auto',
                position: 'relative',
                boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
                m: 2,
            }}>
                {/* Close button */}
                <Button
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        top: 16,
                        right: 16,
                        minWidth: 'auto',
                        p: 1,
                        color: '#94a3b8',
                        '&:hover': {
                            bgcolor: 'rgba(59, 130, 246, 0.1)',
                            color: '#3b82f6',
                        },
                    }}
                >
                    <CloseIcon />
                </Button>

                {/* Item name */}
                <Typography variant="h4" sx={{
                    mb: 2,
                    fontWeight: 700,
                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    pr: 6,
                }}>
                    {item.name}
                </Typography>

                {/* Vulnerability Alert */}
                {vulnAlert && (
                    <Alert severity="success" sx={{ mb: 2 }} onClose={() => setVulnAlert(null)}>
                        <Typography variant="subtitle2" fontWeight={600}>
                            {vulnAlert.name}
                        </Typography>
                        <Typography variant="body2">
                            {vulnAlert.description}
                        </Typography>
                    </Alert>
                )}

                {/* Item details grid */}
                <Box sx={{ mb: 3 }}>
                    <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Typography variant="body2" sx={{ color: '#94a3b8', minWidth: 80 }}>
                            Item ID:
                        </Typography>
                        <Chip
                            label={item.id}
                            size="small"
                            sx={{
                                bgcolor: 'rgba(59, 130, 246, 0.1)',
                                color: '#3b82f6',
                                fontFamily: 'monospace',
                            }}
                        />
                    </Box>

                    <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Typography variant="body2" sx={{ color: '#94a3b8', minWidth: 80 }}>
                            Price:
                        </Typography>
                        <Typography variant="h6" sx={{
                            color: '#10b981',
                            fontWeight: 700,
                        }}>
                            ${Number(item.price).toFixed(2)}
                        </Typography>
                    </Box>

                    <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Typography variant="body2" sx={{ color: '#94a3b8', minWidth: 80 }}>
                            Stock:
                        </Typography>
                        <Chip
                            label={`${fullItem?.stock ?? 'Loading...'} available`}
                            size="small"
                            sx={{
                                bgcolor: fullItem?.stock && fullItem.stock > 0
                                    ? 'rgba(16, 185, 129, 0.1)'
                                    : 'rgba(239, 68, 68, 0.1)',
                                color: fullItem?.stock && fullItem.stock > 0
                                    ? '#10b981'
                                    : '#ef4444',
                                fontWeight: 600,
                            }}
                        />
                    </Box>
                </Box>

                {/* Description */}
                <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" sx={{ color: '#94a3b8', mb: 1 }}>
                        Description:
                    </Typography>
                    <Typography variant="body1" sx={{
                        color: '#f1f5f9',
                        lineHeight: 1.7,
                        p: 2,
                        bgcolor: 'rgba(15, 23, 42, 0.5)',
                        borderRadius: 2,
                        border: '1px solid rgba(59, 130, 246, 0.1)',
                    }}>
                        {fullItem?.description || <CircularProgress size={20} />}
                    </Typography>
                </Box>

                <Divider sx={{ my: 3, borderColor: 'rgba(59, 130, 246, 0.2)' }} />

                {/* Comments Section */}
                <Box sx={{ mb: 3 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                        <CommentIcon sx={{ color: '#8b5cf6', mr: 1 }} />
                        <Typography variant="h6" sx={{ color: '#f1f5f9', fontWeight: 600 }}>
                            Comments ({comments.length})
                        </Typography>
                    </Box>

                    {/* Comment Input */}
                    <Box sx={{ mb: 3 }}>
                        <TextField
                            fullWidth
                            multiline
                            rows={2}
                            placeholder="Add a comment..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            sx={{
                                '& .MuiOutlinedInput-root': {
                                    bgcolor: 'rgba(15, 23, 42, 0.5)',
                                    '& fieldset': { borderColor: 'rgba(59, 130, 246, 0.3)' },
                                    '&:hover fieldset': { borderColor: 'rgba(59, 130, 246, 0.5)' },
                                    '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                },
                                '& textarea': { color: '#f1f5f9' },
                                '& .MuiInputBase-input::placeholder': { color: '#64748b' },
                            }}
                        />
                        <Button
                            variant="contained"
                            startIcon={<SendIcon />}
                            onClick={handleSubmitComment}
                            disabled={loading || !newComment.trim()}
                            sx={{
                                mt: 1,
                                background: 'linear-gradient(135deg, #8b5cf6, #6366f1)',
                                '&:hover': {
                                    background: 'linear-gradient(135deg, #7c3aed, #4f46e5)',
                                },
                            }}
                        >
                            {loading ? 'Posting...' : 'Post Comment'}
                        </Button>
                    </Box>

                    {/* Comments List */}
                    <Box sx={{ maxHeight: 300, overflowY: 'auto' }}>
                        {comments.length === 0 ? (
                            <Typography sx={{ color: '#64748b', textAlign: 'center', py: 3 }}>
                                No comments yet. Be the first to comment!
                            </Typography>
                        ) : (
                            comments.map((comment) => (
                                <Box
                                    key={comment.id}
                                    sx={{
                                        mb: 2,
                                        p: 2,
                                        bgcolor: 'rgba(15, 23, 42, 0.5)',
                                        borderRadius: 2,
                                        border: '1px solid rgba(59, 130, 246, 0.1)',
                                    }}
                                >
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                                        <Typography variant="subtitle2" sx={{ color: '#8b5cf6', fontWeight: 600 }}>
                                            {comment.username}
                                        </Typography>
                                        <Typography variant="caption" sx={{ color: '#64748b' }}>
                                            {new Date(comment.createdAt).toLocaleString()}
                                        </Typography>
                                    </Box>
                                    {/* VULNERABILITY: Using DangerousComment to render HTML */}
                                    <DangerousComment content={comment.content} onXssDetected={handleXssDetected} />
                                </Box>
                            ))
                        )}
                    </Box>
                </Box>

                <Divider sx={{ my: 3, borderColor: 'rgba(59, 130, 246, 0.2)' }} />

                {/* Add to cart button */}
                <Button
                    variant="contained"
                    fullWidth
                    startIcon={<ShoppingCartIcon />}
                    onClick={() => {
                        onAddToCart(item.id)
                        onClose()
                    }}
                    disabled={fullItem?.stock === 0}
                    sx={{
                        background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                        py: 1.5,
                        fontWeight: 600,
                        fontSize: '1rem',
                        '&:hover': {
                            background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
                            transform: 'translateY(-2px)',
                            boxShadow: '0 6px 20px rgba(59, 130, 246, 0.4)',
                        },
                        '&:disabled': {
                            background: 'rgba(59, 130, 246, 0.3)',
                        },
                        transition: 'all 0.3s ease',
                    }}
                >
                    {fullItem?.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                </Button>
            </Box >
        </Modal >
    )
}

export default ItemDetailModal
