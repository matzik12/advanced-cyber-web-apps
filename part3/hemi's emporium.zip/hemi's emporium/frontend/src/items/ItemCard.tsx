import { useState } from 'react'
import { Box, Typography, Button } from '@mui/material'
import './Items.css'
import { useStore } from '../store/StoreProvider'
import ItemDetailModal from './ItemDetailModal'
import type { Item } from '../store/StoreProvider'

type ItemCardProps = {
    id: string
    name: string
    price: number
    description?: string
    stock?: number
}

function ItemCard({ id, name, price, description, stock }: ItemCardProps) {
    const { addToCart } = useStore()
    const [modalOpen, setModalOpen] = useState(false)

    const item: Item = { id, name, price, description, stock }

    return (
        <>
            <Box
                onClick={() => setModalOpen(true)}
                sx={{
                    border: '1px solid rgba(255,255,255,0.06)',
                    p: 2,
                    borderRadius: 1,
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                        transform: 'translateY(-4px)',
                        boxShadow: '0 8px 24px rgba(59, 130, 246, 0.2)',
                        border: '1px solid rgba(59, 130, 246, 0.3)',
                    },
                }}
            >
                <Typography variant="h6">{name}</Typography>
                <Typography variant="subtitle2">${Number(price).toFixed(2)}</Typography>
                <Button
                    sx={{ mt: 1 }}
                    variant="contained"
                    onClick={(e) => {
                        e.stopPropagation() // Prevent modal from opening when clicking add to cart
                        addToCart(id)
                    }}
                >
                    Add to cart
                </Button>
            </Box>

            <ItemDetailModal
                item={item}
                open={modalOpen}
                onClose={() => setModalOpen(false)}
                onAddToCart={addToCart}
            />
        </>
    )
}

export default ItemCard

