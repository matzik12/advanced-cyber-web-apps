import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import './Header.css'
import { AppBar, Toolbar, Typography, Box, Badge, IconButton, Drawer, TextField, Button, Avatar, Dialog, DialogTitle, DialogContent, DialogActions, Alert, Snackbar } from '@mui/material'
import { useStore } from '../store/StoreProvider'
import Cart from '../cart/Cart'
import Vulnerabilities from '../vulnerabilities/Vulnerabilities'
import { addDiscoveredVulnerability, getDiscoveredVulnerabilities } from '../utils/vulnerabilityStorage'

const API_URL = 'http://localhost:3001/api'

function Header() {
    const navigate = useNavigate()

    const handleLogout = () => {
        // Clear authentication data
        localStorage.removeItem('token')
        localStorage.removeItem('user')

        // Clear local state
        setUser(null)

        // Redirect to login page
        navigate('/')
    }

    const { cart, balance, addFunds } = useStore()
    const [openCart, setOpenCart] = useState(false)
    const [openVulnerabilities, setOpenVulnerabilities] = useState(false)
    const [vulnCount, setVulnCount] = useState(0)
    const [openWallet, setOpenWallet] = useState(false)
    const [openProfile, setOpenProfile] = useState(false)
    const [openAvatarEditor, setOpenAvatarEditor] = useState(false)
    const fileInputRef = useRef<HTMLInputElement | null>(null)
    const [avatarUrlInput, setAvatarUrlInput] = useState('')
    const [user, setUser] = useState<any>(null)
    const [fundAmount, setFundAmount] = useState('100')
    const [isAdmin, setIsAdmin] = useState(false)
    const [ssrfAlert, setSsrfAlert] = useState(false)
    const [uploadError, setUploadError] = useState<string | null>(null)

    // Check if user is admin
    useEffect(() => {
        const userStr = localStorage.getItem('user')
        if (userStr) {
            try {
                const user = JSON.parse(userStr)
                setIsAdmin(user.role === 'admin')
            } catch (error) {
                console.error('Failed to parse user:', error)
            }
        }
    }, [])

    // Update vulnerability count from localStorage
    useEffect(() => {
        const updateVulnCount = () => {
            const discovered = getDiscoveredVulnerabilities()
            setVulnCount(discovered.length)
        }

        updateVulnCount()

        // Poll for updates every second
        const interval = setInterval(updateVulnCount, 1000)
        return () => clearInterval(interval)
    }, [])

    // Initialize user state from localStorage and keep in sync
    useEffect(() => {
        const loadUser = () => {
            const userStr = localStorage.getItem('user')
            if (userStr) {
                try {
                    setUser(JSON.parse(userStr))
                } catch {
                    setUser(null)
                }
            } else {
                setUser(null)
            }
        }

        loadUser()

        const onStorage = (e: StorageEvent) => {
            if (e.key === 'user') loadUser()
        }

        const onUserChanged = () => loadUser()

        window.addEventListener('storage', onStorage)
        window.addEventListener('userChanged', onUserChanged)
        return () => {
            window.removeEventListener('storage', onStorage)
            window.removeEventListener('userChanged', onUserChanged)
        }
    }, [])

    const isImageUrl = async (url: string) => {
        const resp = await fetch(url, { method: 'HEAD' });
        const contentType = resp.headers.get('content-type') || '';
        return contentType.startsWith('image/');
    }

    return (
        <>
            <AppBar position="static" sx={{
                background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.5)',
            }}>
                <Toolbar sx={{ py: 1, gap: 2 }}>
                    <Typography variant="h6" sx={{
                        fontWeight: 700,
                        background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                    }}>
                        Hemi's Emporium
                    </Typography>

                    {/* Navigation Buttons */}
                    <Box sx={{ display: 'flex', gap: 1, ml: 3 }}>
                        <Button
                            color="inherit"
                            onClick={() => navigate('/store')}
                            sx={{
                                textTransform: 'none',
                                fontWeight: 500,
                                '&:hover': {
                                    bgcolor: 'rgba(59, 130, 246, 0.1)',
                                }
                            }}
                        >
                            Store Catalog
                        </Button>
                        <Button
                            color="inherit"
                            onClick={() => navigate('/orders')}
                            sx={{
                                textTransform: 'none',
                                fontWeight: 500,
                                '&:hover': {
                                    bgcolor: 'rgba(59, 130, 246, 0.1)'
                                }
                            }}
                        >
                            Order History
                        </Button>
                        {isAdmin && (
                            <Button
                                color="inherit"
                                onClick={() => navigate('/admin')}
                                sx={{
                                    textTransform: 'none',
                                    fontWeight: 500,
                                    bgcolor: 'rgba(139, 92, 246, 0.1)',
                                    border: '1px solid rgba(139, 92, 246, 0.3)',
                                    '&:hover': {
                                        bgcolor: 'rgba(139, 92, 246, 0.2)',
                                    }
                                }}
                            >
                                Admin Dashboard
                            </Button>
                        )}
                    </Box>

                    <Box sx={{ flexGrow: 1 }} />

                    {/* Right side icons and buttons */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Button
                            color="inherit"
                            onClick={() => setOpenWallet(true)}
                            startIcon={<span>💰</span>}
                            sx={{
                                textTransform: 'none',
                                fontWeight: 'bold',
                                bgcolor: 'rgba(34, 197, 94, 0.1)',
                                border: '1px solid rgba(34, 197, 94, 0.3)',
                                '&:hover': {
                                    bgcolor: 'rgba(34, 197, 94, 0.2)',
                                },
                                borderRadius: 2,
                                px: 2,
                            }}
                        >
                            ${balance.toFixed(2)}
                        </Button>
                        <IconButton color="inherit" onClick={() => setOpenVulnerabilities(true)} aria-label="open vulnerabilities">
                            <Badge badgeContent={vulnCount} color="success">
                                <span style={{ fontSize: 20 }}>🏆</span>
                            </Badge>
                        </IconButton>
                        <IconButton color="inherit" onClick={() => setOpenCart(true)} aria-label="open cart">
                            <Badge badgeContent={Object.values(cart).reduce((s, n) => s + n, 0)} color="error">
                                <span style={{ fontSize: 20 }}>🛒</span>
                            </Badge>
                        </IconButton>
                        <Button
                            color="inherit"
                            onClick={() => setOpenProfile(true)}
                            startIcon={<span>👤</span>}
                            sx={{ textTransform: 'none' }}
                        >
                            Profile
                        </Button>
                    </Box>
                </Toolbar>
            </AppBar>

            <Drawer anchor="right" open={openCart} onClose={() => setOpenCart(false)}>
                <Box sx={{ width: 360 }} role="presentation">
                    <Cart />
                </Box>
            </Drawer>

            <Drawer anchor="right" open={openVulnerabilities} onClose={() => setOpenVulnerabilities(false)}>
                <Box sx={{ width: 400 }} role="presentation">
                    <Vulnerabilities />
                </Box>
            </Drawer>

            <Drawer anchor="right" open={openWallet} onClose={() => setOpenWallet(false)}>
                <Box sx={{
                    width: 400,
                    p: 3,
                    bgcolor: '#0f172a',
                    minHeight: '100vh',
                    background: 'linear-gradient(135deg, #0f172a 0%, #1a2332 100%)'
                }} role="presentation">
                    <Typography variant="h5" gutterBottom sx={{
                        fontWeight: 700,
                        background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        mb: 3
                    }}>
                        💰 Wallet
                    </Typography>

                    <Box sx={{
                        bgcolor: 'rgba(30, 41, 59, 0.5)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(59, 130, 246, 0.2)',
                        borderRadius: 3,
                        p: 3,
                        mb: 3,
                        textAlign: 'center',
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                    }}>
                        <Typography variant="subtitle2" sx={{ color: '#94a3b8', mb: 1 }}>
                            Current Balance
                        </Typography>
                        <Typography variant="h3" sx={{
                            fontWeight: 700,
                            background: 'linear-gradient(135deg, #10b981, #34d399)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                        }}>
                            ${balance.toFixed(2)}
                        </Typography>
                    </Box>

                    <Box sx={{
                        bgcolor: 'rgba(30, 41, 59, 0.5)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(59, 130, 246, 0.1)',
                        borderRadius: 3,
                        p: 3,
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                    }}>
                        <Typography variant="subtitle1" gutterBottom sx={{ color: '#f1f5f9', fontWeight: 600, mb: 2 }}>
                            Add Funds
                        </Typography>
                        <TextField
                            label="Amount"
                            type="number"
                            value={fundAmount}
                            onChange={(e) => setFundAmount(e.target.value)}
                            fullWidth
                            sx={{
                                mb: 2,
                                '& .MuiOutlinedInput-root': {
                                    bgcolor: 'rgba(15, 23, 42, 0.5)',
                                    '& fieldset': {
                                        borderColor: 'rgba(59, 130, 246, 0.3)',
                                    },
                                    '&:hover fieldset': {
                                        borderColor: 'rgba(59, 130, 246, 0.5)',
                                    },
                                    '&.Mui-focused fieldset': {
                                        borderColor: '#3b82f6',
                                    },
                                },
                                '& input': {
                                    color: '#f1f5f9',
                                },
                                '& label': {
                                    color: '#94a3b8',
                                },
                                '& label.Mui-focused': {
                                    color: '#3b82f6',
                                }
                            }}
                        />
                        <Button
                            variant="contained"
                            fullWidth
                            onClick={async () => {
                                const amount = Number(fundAmount)
                                if (amount > 0) {
                                    await addFunds(amount)
                                    setFundAmount('100')
                                }
                            }}
                            sx={{
                                background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                                py: 1.5,
                                fontWeight: 600,
                                '&:hover': {
                                    background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
                                    transform: 'translateY(-2px)',
                                    boxShadow: '0 6px 20px rgba(59, 130, 246, 0.4)',
                                },
                                transition: 'all 0.3s ease',
                            }}
                        >
                            Add Funds
                        </Button>
                    </Box>
                </Box>
            </Drawer>

            <Drawer anchor="right" open={openProfile} onClose={() => setOpenProfile(false)}>
                <Box sx={{
                    width: 400,
                    p: 3,
                    bgcolor: '#0f172a',
                    minHeight: '100vh',
                    background: 'linear-gradient(135deg, #0f172a 0%, #1a2332 100%)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between'
                }} role="presentation">
                    <Box>
                        <Typography variant="h5" gutterBottom sx={{
                            fontWeight: 700,
                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            mb: 2
                        }}>
                            👤 Profile
                        </Typography>

                        {
                            (() => {

                                try {
                                    const name = user.name || user.username || 'User'
                                    const initials = (name.split(' ').map((s: string) => s[0]).join('').slice(0, 2) || 'U').toUpperCase()
                                    return (
                                        <Box>
                                            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                                                <Box sx={{ position: 'relative', display: 'inline-block' }}>
                                                    {user && user.avatarUrl ? (
                                                        <Avatar src={user.avatarUrl} sx={{ width: 96, height: 96, cursor: 'pointer' }} onClick={() => setOpenAvatarEditor(true)} />
                                                    ) : (
                                                        <Avatar sx={{ width: 96, height: 96, fontSize: 32, cursor: 'pointer' }} onClick={() => setOpenAvatarEditor(true)}>{initials}</Avatar>
                                                    )}

                                                    <Box sx={{
                                                        position: 'absolute',
                                                        bottom: -6,
                                                        right: -6,
                                                        width: 28,
                                                        height: 28,
                                                        bgcolor: 'rgba(15, 23, 42, 0.85)',
                                                        color: '#fff',
                                                        borderRadius: '50%',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        fontSize: 12,
                                                        border: '1px solid rgba(59,130,246,0.18)',
                                                        zIndex: 5,
                                                        pointerEvents: 'none'
                                                    }}>
                                                        ✏️
                                                    </Box>
                                                </Box>
                                            </Box>

                                            <Box sx={{
                                                bgcolor: 'rgba(30, 41, 59, 0.5)',
                                                backdropFilter: 'blur(10px)',
                                                border: '1px solid rgba(59, 130, 246, 0.1)',
                                                borderRadius: 3,
                                                p: 3,
                                                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
                                            }}>
                                                <Typography sx={{ fontWeight: 600, color: '#3b82f6' }}>{name}</Typography>
                                                {user.email && <Typography sx={{ color: '#94a3b8', mb: 1 }}>{user.email}</Typography>}
                                                <Typography sx={{ mb: 1, color: '#3b82f6' }}>Role: {user.role || 'student'}</Typography>
                                            </Box>
                                        </Box>
                                    )
                                } catch (e) {
                                    return <Typography sx={{ color: '#f43f5e' }}>Failed to load user info.</Typography>
                                }
                            })()
                        }
                    </Box>

                    {/* Avatar editor dialog (styled to match site) */}
                    <Dialog
                        open={openAvatarEditor}
                        onClose={() => setOpenAvatarEditor(false)}
                        PaperProps={{ sx: { bgcolor: '#0f172a', color: '#f1f5f9', borderRadius: 2 } }}
                    >
                        <DialogTitle sx={{
                            fontWeight: 700,
                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent'
                        }}>Change Avatar</DialogTitle>

                        <DialogContent>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 360 }}>
                                <Box sx={{
                                    bgcolor: 'rgba(30, 41, 59, 0.5)',
                                    backdropFilter: 'blur(8px)',
                                    border: '1px solid rgba(59, 130, 246, 0.08)',
                                    borderRadius: 2,
                                    p: 2,
                                    display: 'flex',
                                    gap: 2,
                                    alignItems: 'center'
                                }}>
                                    <Button
                                        variant="contained"
                                        onClick={() => fileInputRef.current?.click()}
                                        sx={{
                                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                                            color: '#fff',
                                            textTransform: 'none'
                                        }}
                                    >
                                        Upload Image File
                                    </Button>
                                </Box>
                                <Typography sx={{ color: '#94a3b8', fontSize: 15 }}>OR</Typography>

                                <input
                                    ref={fileInputRef}
                                    type="file"
                                    accept="image/*"
                                    style={{ display: 'none' }}
                                    onChange={async (e) => {
                                        const f = e.target.files && e.target.files[0]
                                        if (!f) return
                                        const reader = new FileReader()
                                        reader.onload = async () => {
                                            const data = reader.result as string
                                            try {
                                                // Try to persist first; abort if the server rejects it (e.g. payload too large)
                                                const token = localStorage.getItem('token')
                                                if (token) {
                                                    const res = await fetch(`${API_URL}/profile/avatar`, {
                                                        method: 'PUT',
                                                        headers: {
                                                            'Content-Type': 'application/json',
                                                            'Authorization': `Bearer ${token}`,
                                                        },
                                                        body: JSON.stringify({ imageData: data }),
                                                    })
                                                    if (res.status === 413 || !res.ok) {
                                                        const isTooBig = res.status === 413
                                                        setUploadError(isTooBig
                                                            ? 'Image is too large. Please choose a smaller file.'
                                                            : 'Failed to upload image. Please try again.')
                                                        return  // Do NOT set the image in local state
                                                    }
                                                }

                                                // Only update local state if server accepted it
                                                try {
                                                    const userStr = localStorage.getItem('user')
                                                    const u = userStr ? JSON.parse(userStr) : {}
                                                    u.avatarUrl = data
                                                    localStorage.setItem('user', JSON.stringify(u))
                                                    try { window.dispatchEvent(new Event('userChanged')) } catch (e) { }
                                                    setUser(u)
                                                    setOpenAvatarEditor(false)
                                                } catch (err) {
                                                    console.error('Failed to save avatar', err)
                                                }
                                            } catch (err) {
                                                console.error('Failed to upload avatar', err)
                                                setUploadError('Network error. Please check your connection.')
                                            }
                                        }
                                        reader.readAsDataURL(f)
                                    }}
                                />

                                <TextField
                                    label="Paste Image URL"
                                    value={avatarUrlInput}
                                    onChange={(e) => setAvatarUrlInput(e.target.value)}
                                    fullWidth
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                                            '& fieldset': { borderColor: 'rgba(59,130,246,0.12)' },
                                            '&:hover fieldset': { borderColor: 'rgba(59,130,246,0.3)' },
                                        },
                                        '& input': { color: '#f1f5f9' },
                                        '& label': { color: '#94a3b8' }
                                    }}
                                />
                            </Box>
                        </DialogContent>

                        <DialogActions sx={{ p: 2 }}>
                            <Button color="inherit" onClick={() => setOpenAvatarEditor(false)} sx={{ textTransform: 'none' }}>Cancel</Button>
                            <Button
                                variant="contained"
                                onClick={() => {
                                    const url = avatarUrlInput.trim()
                                    if (!url) return
                                    try {
                                        isImageUrl(url).then(isImg => {
                                            if (!isImg) {
                                                addDiscoveredVulnerability('SSRF_AVATAR');
                                                setSsrfAlert(true);
                                            }
                                        });
                                        const userStr = localStorage.getItem('user')
                                        const u = userStr ? JSON.parse(userStr) : {}
                                        u.avatarUrl = url
                                        localStorage.setItem('user', JSON.stringify(u))
                                        try { window.dispatchEvent(new Event('userChanged')) } catch (e) { }
                                        setUser(u)
                                        setAvatarUrlInput('')
                                        setOpenAvatarEditor(false)
                                        // Persist avatar URL to backend (best-effort)
                                        try {
                                            const token = localStorage.getItem('token')
                                            if (token) {
                                                void fetch(`${API_URL}/profile/avatar`, {
                                                    method: 'PUT',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'Authorization': `Bearer ${token}`,
                                                    },
                                                    body: JSON.stringify({ imageUrl: url }),
                                                })
                                            }
                                        } catch (err) {
                                            console.error('Failed to persist avatar url to server', err)
                                        }
                                    } catch (err) {
                                        console.error('Failed to save avatar url', err)
                                    }
                                }}
                                sx={{ background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)', textTransform: 'none' }}
                            >
                                Save
                            </Button>
                        </DialogActions>
                    </Dialog>

                    <Box>
                        <Button
                            variant="contained"
                            fullWidth
                            onClick={() => {
                                setOpenProfile(false)
                                handleLogout()
                            }}
                            sx={{
                                background: 'linear-gradient(135deg, #ef4444, #f97316)',
                                py: 1.2,
                                fontWeight: 600,
                                '&:hover': {
                                    transform: 'translateY(-2px)'
                                }
                            }}
                        >
                            Logout
                        </Button>
                    </Box>
                </Box>
            </Drawer>
            <Snackbar
                open={ssrfAlert}
                autoHideDuration={8000}
                onClose={() => setSsrfAlert(false)}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert severity="success" onClose={() => setSsrfAlert(false)} sx={{ width: '100%' }}>
                    <Typography variant="subtitle2" fontWeight={700}>🎉 SSRF Vulnerability Discovered!</Typography>
                    <Typography variant="body2">You found a Server-Side Request Forgery vulnerability! By providing a non-image URL as an avatar, you tricked the server into making requests to arbitrary internal or external endpoints.</Typography>
                </Alert>
            </Snackbar>

            <Snackbar
                open={!!uploadError}
                autoHideDuration={6000}
                onClose={() => setUploadError(null)}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert severity="error" onClose={() => setUploadError(null)} sx={{ width: '100%' }}>
                    {uploadError}
                </Alert>
            </Snackbar>
        </>
    )
}

export default Header
