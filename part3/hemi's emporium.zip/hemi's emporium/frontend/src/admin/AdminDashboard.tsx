import { useState } from 'react'
import { Box, Typography, TextField, Button, Alert, Grid, Paper } from '@mui/material'
import Header from '../header/Header'
import './AdminDashboard.css'

function AdminDashboard() {
    const [name, setName] = useState('')
    const [description, setDescription] = useState('')
    const [price, setPrice] = useState('')
    const [stock, setStock] = useState('')
    const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)
    const [loading, setLoading] = useState(false)

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setMessage(null)
        setLoading(true)

        try {
            const token = localStorage.getItem('token')
            const response = await fetch('http://localhost:3001/api/products', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({
                    name,
                    description,
                    price: parseFloat(price),
                    stock: parseInt(stock) || 0,
                }),
            })

            const data = await response.json()

            if (data.success) {
                setMessage({ type: 'success', text: data.message })
                // Clear form
                setName('')
                setDescription('')
                setPrice('')
                setStock('')
            } else {
                setMessage({ type: 'error', text: data.message })
            }
        } catch (error) {
            setMessage({ type: 'error', text: 'Failed to create product' })
        } finally {
            setLoading(false)
        }
    }

    return (
        <>
            <Header />
            <Box sx={{
                p: 4,
                maxWidth: 1200,
                mx: 'auto',
                minHeight: 'calc(100vh - 64px)',
                bgcolor: '#0f172a'
            }}>
                <Typography variant="h4" gutterBottom sx={{
                    mb: 4,
                    fontWeight: 700,
                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                }}>
                    🔧 Admin Dashboard
                </Typography>

                <Paper sx={{
                    bgcolor: 'rgba(30, 41, 59, 0.5)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(59, 130, 246, 0.1)',
                    borderRadius: 3,
                    p: 4,
                }}>
                    <Typography variant="h5" sx={{ color: '#f1f5f9', mb: 3, fontWeight: 600 }}>
                        Add New Product
                    </Typography>

                    {message && (
                        <Alert severity={message.type} sx={{ mb: 3 }}>
                            {message.text}
                        </Alert>
                    )}

                    <Box component="form" onSubmit={handleSubmit}>
                        <Grid container spacing={3}>
                            <Grid size={{ xs: 12, sm: 6 }}>
                                <TextField
                                    label="Product Name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                    fullWidth
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                                            '& fieldset': { borderColor: 'rgba(59, 130, 246, 0.3)' },
                                            '&:hover fieldset': { borderColor: 'rgba(59, 130, 246, 0.5)' },
                                            '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                        },
                                        '& input': { color: '#f1f5f9' },
                                        '& label': { color: '#94a3b8' },
                                        '& label.Mui-focused': { color: '#3b82f6' },
                                    }}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 6 }}>
                                <TextField
                                    label="Price"
                                    type="number"
                                    value={price}
                                    onChange={(e) => setPrice(e.target.value)}
                                    required
                                    fullWidth
                                    inputProps={{ step: '0.01', min: '0' }}
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                                            '& fieldset': { borderColor: 'rgba(59, 130, 246, 0.3)' },
                                            '&:hover fieldset': { borderColor: 'rgba(59, 130, 246, 0.5)' },
                                            '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                        },
                                        '& input': { color: '#f1f5f9' },
                                        '& label': { color: '#94a3b8' },
                                        '& label.Mui-focused': { color: '#3b82f6' },
                                    }}
                                />
                            </Grid>

                            <Grid size={{ xs: 12, sm: 6 }}>
                                <TextField
                                    label="Stock"
                                    type="number"
                                    value={stock}
                                    onChange={(e) => setStock(e.target.value)}
                                    fullWidth
                                    inputProps={{ min: '0' }}
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                                            '& fieldset': { borderColor: 'rgba(59, 130, 246, 0.3)' },
                                            '&:hover fieldset': { borderColor: 'rgba(59, 130, 246, 0.5)' },
                                            '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                        },
                                        '& input': { color: '#f1f5f9' },
                                        '& label': { color: '#94a3b8' },
                                        '& label.Mui-focused': { color: '#3b82f6' },
                                    }}
                                />
                            </Grid>

                            <Grid size={{ xs: 12 }}>
                                <TextField
                                    label="Description"
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    multiline
                                    rows={4}
                                    fullWidth
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            bgcolor: 'rgba(15, 23, 42, 0.5)',
                                            '& fieldset': { borderColor: 'rgba(59, 130, 246, 0.3)' },
                                            '&:hover fieldset': { borderColor: 'rgba(59, 130, 246, 0.5)' },
                                            '&.Mui-focused fieldset': { borderColor: '#3b82f6' },
                                        },
                                        '& textarea': { color: '#f1f5f9' },
                                        '& label': { color: '#94a3b8' },
                                        '& label.Mui-focused': { color: '#3b82f6' },
                                    }}
                                />
                            </Grid>

                            <Grid size={{ xs: 12 }}>
                                <Button
                                    type="submit"
                                    variant="contained"
                                    disabled={loading}
                                    fullWidth
                                    sx={{
                                        background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                                        py: 1.5,
                                        fontWeight: 600,
                                        fontSize: '1rem',
                                        '&:hover': {
                                            background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
                                            transform: 'translateY(-2px)',
                                            boxShadow: '0 6px 20px rgba(59, 130, 246, 0.4)',
                                        },
                                        '&:disabled': {
                                            background: 'rgba(59, 130, 246, 0.3)',
                                        },
                                        transition: 'all 0.3s ease',
                                    }}
                                >
                                    {loading ? 'Creating Product...' : 'Create Product'}
                                </Button>
                            </Grid>
                        </Grid>
                    </Box>
                </Paper>
            </Box>
        </>
    )
}

export default AdminDashboard
