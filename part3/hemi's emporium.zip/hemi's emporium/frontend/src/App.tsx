
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Store from './store/Store'
import Login from './login/Login'
import Register from './register/Register'
import ProtectedRoute from './ProtectedRoute'
import Orders from './orders/Orders'
import AdminDashboard from './admin/AdminDashboard'
import StoreProvider from './store/StoreProvider'
import Chatbot from './chatbot/Chatbot'
import PasswordReset from './auth/PasswordReset'

function App() {
  return (
    <BrowserRouter>
      <StoreProvider>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/store' element={
            <ProtectedRoute>
              <Store />
            </ProtectedRoute>
          } />
          <Route path='/orders' element={
            <ProtectedRoute>
              <Orders />
            </ProtectedRoute>
          } />
          <Route path='/admin' element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } />
          <Route path='/signup' element={<Register />} />
          <Route path='/reset' element={<PasswordReset />} />
        </Routes>
        <Chatbot />
      </StoreProvider>
    </BrowserRouter>
  )
}

export default App
