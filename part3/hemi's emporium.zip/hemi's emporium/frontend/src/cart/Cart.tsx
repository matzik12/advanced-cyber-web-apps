import { useStore } from '../store/StoreProvider'
import { Box, Typography, Button, CircularProgress, Alert } from '@mui/material'
import './Cart.css'
import { useState } from 'react'

function Cart() {
    const { cartItems, clearCart, removeFromCart, loading, checkout, balance } = useStore()
    const [checkoutMessage, setCheckoutMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null)

    const total = cartItems.reduce((s, item) => s + (Number(item.product?.price) || 0) * item.quantity, 0)

    if (loading) {
        return (
            <Box sx={{ p: 3, bgcolor: '#0f172a', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <CircularProgress />
            </Box>
        )
    }

    return (
        <Box sx={{ p: 3, bgcolor: '#0f172a', minHeight: '100vh' }}>
            <Box className="drawer-header" sx={{ mx: -3, mt: -3, mb: 3 }}>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#f1f5f9' }}>
                    🛒 Shopping Cart
                </Typography>
            </Box>

            {cartItems.length === 0 && (
                <Box sx={{
                    textAlign: 'center',
                    py: 4,
                    color: '#94a3b8'
                }}>
                    <Typography variant="h6" sx={{ mb: 1 }}>Your cart is empty</Typography>
                    <Typography variant="body2">Add some items to get started!</Typography>
                </Box>
            )}

            {cartItems.map((item) => (
                <Box key={item.id} className="cart-item">
                    <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', justifyContent: 'space-between' }}>
                        <Box sx={{ flex: 1 }}>
                            <Typography sx={{ color: '#f1f5f9', fontWeight: 600 }}>
                                {item.product?.name || 'Unknown Product'}
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#94a3b8' }}>
                                Quantity: {item.quantity}
                            </Typography>
                        </Box>
                        <Typography sx={{ color: '#3b82f6', fontWeight: 600, fontSize: '1.1rem' }}>
                            ${((Number(item.product?.price) || 0) * item.quantity).toFixed(2)}
                        </Typography>
                        <Button
                            size="small"
                            onClick={() => removeFromCart(item.productId)}
                            sx={{
                                minWidth: '36px',
                                bgcolor: 'rgba(239, 68, 68, 0.1)',
                                color: '#ef4444',
                                '&:hover': {
                                    bgcolor: 'rgba(239, 68, 68, 0.2)',
                                }
                            }}
                        >
                            −
                        </Button>
                    </Box>
                </Box>
            ))}

            {cartItems.length > 0 && (
                <Box className="cart-total" sx={{ mt: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h6" sx={{ color: '#f1f5f9', fontWeight: 700 }}>
                            Total:
                        </Typography>
                        <Typography variant="h5" sx={{
                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            fontWeight: 700
                        }}>
                            ${total.toFixed(2)}
                        </Typography>
                    </Box>

                    {checkoutMessage && (
                        <Alert severity={checkoutMessage.type} sx={{ mb: 2 }}>
                            {checkoutMessage.text}
                        </Alert>
                    )}

                    <Button
                        variant="contained"
                        fullWidth
                        sx={{
                            mb: 2,
                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                            '&:hover': {
                                background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
                            }
                        }}
                        onClick={async () => {
                            const result = await checkout()
                            if (result.success) {
                                setCheckoutMessage({ type: 'success', text: `Order placed! New balance: $${result.newBalance.toFixed(2)}` })
                                setTimeout(() => setCheckoutMessage(null), 5000)
                            } else {
                                setCheckoutMessage({ type: 'error', text: result.message || 'Checkout failed' })
                                setTimeout(() => setCheckoutMessage(null), 5000)
                            }
                        }}
                    >
                        Checkout (Balance: ${balance.toFixed(2)})
                    </Button>
                    <Button
                        variant="outlined"
                        onClick={clearCart}
                        fullWidth
                        sx={{
                            borderColor: 'rgba(239, 68, 68, 0.5)',
                            color: '#ef4444',
                            '&:hover': {
                                borderColor: '#ef4444',
                                bgcolor: 'rgba(239, 68, 68, 0.1)',
                            }
                        }}
                    >
                        Clear Cart
                    </Button>
                </Box>
            )}
        </Box>
    )
}

export default Cart
