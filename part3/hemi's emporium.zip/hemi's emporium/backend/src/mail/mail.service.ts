import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

const ADMIN_EMAIL = 'admin@hemi-emporium.local';

@Injectable()
export class MailService {
    // All non-admin emails go to the MailHog instance (visible on localhost:8025)
    private transporter = nodemailer.createTransport({
        host: process.env.MAILHOG_HOST || 'mailhog',
        port: parseInt(process.env.MAILHOG_PORT || '1025'),
        secure: false,
        ignoreTLS: true,
    });

    async sendPasswordResetEmail(to: string, token: string): Promise<void> {
        // Admin email is silently dropped — token never appears in MailHog
        // Students must brute-force the weak timestamp token to reset the admin's password
        if (to === ADMIN_EMAIL) {
            return;
        }

        const resetUrl = `${process.env.APP_URL || 'http://localhost:5173'}/reset`;

        await this.transporter.sendMail({
            from: '"Hemi\'s Emporium" <noreply@hemi-emporium.local>',
            to,
            subject: 'Password Reset Request',
            html: `
                <h2>Password Reset</h2>
                <p>You requested a password reset for your Hemi's Emporium account.</p>
                <p>Your reset token is: <strong style="font-family:monospace;font-size:1.1em">${token}</strong></p>
                <p>Go to <a href="${resetUrl}">${resetUrl}</a>, enter this token, and choose a new password.</p>
                <p>If you did not request this, please ignore this email.</p>
            `,
        });
    }
}
