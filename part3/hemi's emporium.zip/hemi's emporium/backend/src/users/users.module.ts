import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './user.entity';
import { UsersService } from './users.service';
import { WalletController } from './wallet.controller';
import { ProfileController } from './profile.controller';

@Module({
    imports: [TypeOrmModule.forFeature([User])],
    providers: [UsersService],
    controllers: [WalletController, ProfileController],
    exports: [UsersService],
})
export class UsersModule { }
