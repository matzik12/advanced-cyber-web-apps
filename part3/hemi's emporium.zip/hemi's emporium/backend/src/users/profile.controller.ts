import { Controller, Put, Body, Headers } from '@nestjs/common';
import { UsersService } from './users.service';
import * as jwt from 'jsonwebtoken';

@Controller('profile')
export class ProfileController {
    constructor(private usersService: UsersService) { }

    private getUserIdFromToken(authHeader: string): string | null {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) return null;

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );
            return decoded.sub;
        } catch (error) {
            return null;
        }
    }

    @Put('avatar')
    async updateAvatar(
        @Headers('authorization') authHeader: string,
        @Body() body: { imageUrl?: string; imageData?: string },
    ) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const update: Partial<any> = {};

        // Ensure only one of the avatar fields is set at a time.
        // If the client supplies imageUrl, clear imageData. If imageData is supplied, clear imageUrl.
        if (typeof body.imageUrl === 'string') {
            update.imageUrl = body.imageUrl || null;
            update.imageData = null;
        }

        if (typeof body.imageData === 'string') {
            update.imageData = body.imageData || null;
            update.imageUrl = null;
        }

        if (!('imageUrl' in update) && !('imageData' in update)) {
            return { success: false, message: 'No image provided' };
        }

        const user = await this.usersService.update(userId, update);
        if (!user) {
            return { success: false, message: 'User not found' };
        }

        return {
            success: true,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                imageUrl: (user as any).imageUrl || null,
                imageData: (user as any).imageData || null,
            },
        };
    }
}
