import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity('users')
export class User {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ unique: true })
    username: string;

    // VULNERABILITY: Passwords stored in plaintext
    @Column()
    password: string;

    @Column({ nullable: true })
    email: string;

    @CreateDateColumn()
    createdAt: Date;

    @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
    balance: number;

    @Column({ type: 'enum', enum: ['user', 'admin'], default: 'user' })
    role: string;

    @Column({ default: false })
    isAdmin: boolean;

    // Optional avatar fields
    @Column({ nullable: true })
    imageUrl?: string;

    @Column({ type: 'text', nullable: true })
    imageData?: string;
}
