import { Controller, Post, Get, Body, Headers } from '@nestjs/common';
import { UsersService } from './users.service';
import * as jwt from 'jsonwebtoken';

@Controller('wallet')
export class WalletController {
    constructor(private usersService: UsersService) { }

    private getUserIdFromToken(authHeader: string): string | null {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) return null;

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );
            return decoded.sub;
        } catch (error) {
            return null;
        }
    }

    @Get()
    async getBalance(@Headers('authorization') authHeader: string) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const user = await this.usersService.findById(userId);
        if (!user) {
            return { success: false, message: 'User not found' };
        }

        return {
            success: true,
            balance: user.balance || 0,
        };
    }

    @Post('add-funds')
    async addFunds(
        @Headers('authorization') authHeader: string,
        @Body() body: { amount: number },
    ) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const user = await this.usersService.findById(userId);
        if (!user) {
            return { success: false, message: 'User not found' };
        }

        // Add funds (in a real app, this would integrate with a payment processor)
        const newBalance = (Number(user.balance) || 0) + Number(body.amount);
        await this.usersService.updateBalance(userId, newBalance);

        return {
            success: true,
            balance: newBalance,
            message: `Added $${body.amount} to your wallet`,
        };
    }
}
