import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { User } from './user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
    constructor(
        @InjectRepository(User)
        private usersRepository: Repository<User>,
        private dataSource: DataSource,
    ) { }

    // VULNERABILITY: Using raw SQL queries susceptible to SQL injection
    async findByUsername(username: string): Promise<User | null> {
        // This method is intentionally vulnerable for educational purposes
        const query = `SELECT * FROM users WHERE username = '${username}'`;
        console.log('Executing query:', query); // Logging for educational purposes

        try {
            const result = await this.dataSource.query(query);
            return result[0] || null;
        } catch (error) {
            console.error('Query error:', error.message);
            return null;
        }
    }

    async findById(id: string): Promise<User | null> {
        return this.usersRepository.findOne({ where: { id } });
    }

    async create(userData: Partial<User>): Promise<User> {
        const user = this.usersRepository.create(userData);
        return this.usersRepository.save(user);
    }

    async seedUsers() {
        const count = await this.usersRepository.count();
        if (count > 0) {
            return;
        }

        const testUser = this.usersRepository.create({
            username: 'testuser',
            email: 'test@example.com',
            password: 'password123', // Plain text password (vulnerability)
            balance: 1000,
            role: 'user',
        });

        await this.usersRepository.save(testUser);

        // Create admin user from environment variables if provided
        const adminUsername = process.env.ADMIN_USERNAME;
        const adminPassword = process.env.ADMIN_PASSWORD;

        if (adminUsername && adminPassword) {
            const adminUser = this.usersRepository.create({
                username: adminUsername,
                email: 'admin@hemi-emporium.local',  // Fixed known email — required for WEAK_RESET_TOKEN vuln
                password: adminPassword, // Plain text password (vulnerability)
                balance: 10000,
                role: 'admin',
            });

            await this.usersRepository.save(adminUser);
            console.log(`  ✓ Created admin user: ${adminUsername} <admin@hemi-emporium.local>`);
        }
    }

    async update(id: string, userData: Partial<User>): Promise<User> {
        await this.usersRepository.update(id, userData);
        return this.findById(id);
    }

    async updateBalance(userId: string, newBalance: number): Promise<void> {
        await this.usersRepository.update(userId, { balance: newBalance });
    }
    async findByEmail(email: string): Promise<User | null> {
        return this.usersRepository.findOne({ where: { email } });
    }

    // VULNERABILITY: password stored as plaintext (consistent with the rest of the app)
    async updatePassword(userId: string, newPassword: string): Promise<void> {
        await this.usersRepository.update(userId, { password: newPassword });
    }
}
