import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DataSource } from 'typeorm';
import { Product } from './products/product.entity';
import { Comment } from './comments/comment.entity';
import { Order } from './orders/order.entity';
import { OrderItem } from './orders/order-item.entity';
import { UsersService } from './users/users.service';

async function seed() {
    console.log('🌱 Starting database seeding...');

    try {
        const app = await NestFactory.createApplicationContext(AppModule);
        const dataSource = app.get(DataSource);
        const usersService = app.get(UsersService);

        console.log('  Connected to database');

        // Guard: skip seeding if data already exists unless FORCE_RESEED=true
        const existingUserCount = await dataSource.query(`SELECT COUNT(*) FROM "users"`).catch(() => [{ count: '0' }]);
        const hasData = parseInt(existingUserCount[0]?.count ?? '0', 10) > 0;

        if (hasData && process.env.FORCE_RESEED !== 'true') {
            console.log('\n✅ Database already seeded. Skipping.');
            console.log('   Set FORCE_RESEED=true to wipe and re-seed.');
            await app.close();
            process.exit(0);
        }

        if (hasData) {
            console.log('\n FORCE_RESEED=true — wiping existing data...');
        }

        // Clear existing data with CASCADE to handle foreign keys
        console.log('Clearing existing data...');
        await dataSource.query('TRUNCATE TABLE "products" CASCADE');
        await dataSource.query('TRUNCATE TABLE "users" CASCADE');
        await dataSource.query('TRUNCATE TABLE "cart_items" CASCADE');
        await dataSource.query('TRUNCATE TABLE "orders" CASCADE');
        await dataSource.query('TRUNCATE TABLE "order_items" CASCADE');

        console.log('✅ Cleared existing data');

        // Wait for database synchronization to complete
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Seed users (includes admin if env vars are set)
        console.log('\n📝 Seeding users...');
        await usersService.seedUsers();
        console.log('✅ Users seeded successfully');

        const productRepository = dataSource.getRepository(Product);

        // Dummy products
        const productsData = [
            {
                name: 'Laptop',
                description: 'High-performance laptop with 16GB RAM',
                price: 999.99,
                stock: 50,
            },
            {
                name: 'Wireless Mouse',
                description: 'Ergonomic wireless mouse with precision tracking',
                price: 29.99,
                stock: 200,
            },
            {
                name: 'Mechanical Keyboard',
                description: 'RGB mechanical keyboard with Cherry MX switches',
                price: 149.99,
                stock: 75,
            },
            {
                name: 'USB-C Hub',
                description: '7-in-1 USB-C hub with 4K HDMI output',
                price: 49.99,
                stock: 150,
            },
            {
                name: 'Webcam',
                description: '1080p HD webcam with auto-focus',
                price: 79.99,
                stock: 100,
            },
            {
                name: 'Headphones',
                description: 'Noise-cancelling wireless headphones',
                price: 199.99,
                stock: 60,
            },
            {
                name: 'Monitor',
                description: '27-inch 4K monitor with HDR support',
                price: 399.99,
                stock: 40,
            },
            {
                name: 'External SSD',
                description: '1TB portable SSD with USB 3.2',
                price: 129.99,
                stock: 120,
            },
            {
                name: 'Phone Stand',
                description: 'Adjustable aluminum phone stand',
                price: 19.99,
                stock: 300,
            },
            {
                name: 'Cable Organizer',
                description: 'Set of 10 cable organizers and clips',
                price: 12.99,
                stock: 500,
            },
            {
                name: "Hemi Plushie",
                description: "Exclusive limited time limited edition Dr Hemi's plushie",
                price: 10000.0,
                stock: 1

            }
        ];

        // Insert products
        console.log('\n📦 Seeding products...');
        for (const productData of productsData) {
            const product = productRepository.create(productData);
            await productRepository.save(product);
            console.log(`  ✓ Created product: ${product.name}`);
        }

        console.log(`\n✅ Successfully seeded ${productsData.length} products!`);

        // Fetch saved products and users for seeding relations
        const savedProducts = await productRepository.find();
        const [adminUser] = await dataSource.query(`SELECT * FROM users WHERE role = 'admin' LIMIT 1`);
        const [testUser] = await dataSource.query(`SELECT * FROM users WHERE username = 'testuser' LIMIT 1`);

        if (adminUser && testUser && savedProducts.length > 0) {
            const commentRepository = dataSource.getRepository(Comment);
            const orderRepository = dataSource.getRepository(Order);
            const orderItemRepository = dataSource.getRepository(OrderItem);

            const byName = (name: string) => savedProducts.find(p => p.name === name)!;
            const laptop = byName('Laptop');
            const mouse = byName('Wireless Mouse');
            const keyboard = byName('Mechanical Keyboard');
            const headphones = byName('Headphones');
            const monitor = byName('Monitor');

            // ── Comments ─────────────────────────────────────────────────
            console.log('\n💬 Seeding comments...');
            const commentsData = [
                { product: laptop, user: adminUser, content: 'Top-notch performance. Perfect for our lab setups.' },
                { product: laptop, user: testUser, content: 'Runs everything I throw at it. Highly recommend!' },
                { product: mouse, user: testUser, content: 'Very comfortable for long sessions. No lag at all.' },
                { product: keyboard, user: adminUser, content: 'The Cherry MX switches feel amazing. Great build quality.' },
                { product: keyboard, user: testUser, content: 'RGB looks fantastic. A bit loud but worth it.' },
                { product: headphones, user: testUser, content: 'Best noise cancelling I\'ve used. Crystal clear audio.' },
                { product: monitor, user: adminUser, content: '4K HDR is stunning. Perfect for both work and gaming.' },
            ];

            for (const c of commentsData) {
                if (!c.product) continue;
                const comment = commentRepository.create({
                    productId: c.product.id,
                    userId: c.user.id,
                    username: c.user.username,
                    content: c.content,
                });
                await commentRepository.save(comment);
                console.log(`  ✓ Comment on "${c.product.name}" by ${c.user.username}`);
            }
            console.log('✅ Comments seeded');

            // ── Orders ────────────────────────────────────────────────────
            console.log('\n🛒 Seeding orders...');

            const makeOrder = async (user: any, items: { product: Product; qty: number }[]) => {
                const total = items.reduce((sum, i) => sum + i.product.price * i.qty, 0);
                const order = orderRepository.create({ userId: user.id, total, status: 'completed' });
                await orderRepository.save(order);
                for (const { product, qty } of items) {
                    const item = orderItemRepository.create({
                        orderId: order.id,
                        productId: product.id,
                        quantity: qty,
                        price: product.price,
                    });
                    await orderItemRepository.save(item);
                }
                console.log(`  ✓ Order for ${user.username}: ${items.map(i => i.product.name).join(', ')} (total $${total.toFixed(2)})`);
            };

            // admin orders
            await makeOrder(adminUser, [
                { product: laptop, qty: 2 },
                { product: monitor, qty: 1 },
            ]);
            await makeOrder(adminUser, [
                { product: keyboard, qty: 3 },
                { product: mouse, qty: 3 },
            ]);

            // testuser orders
            await makeOrder(testUser, [
                { product: headphones, qty: 1 },
                { product: mouse, qty: 1 },
            ]);
            await makeOrder(testUser, [
                { product: keyboard, qty: 1 },
                { product: byName('USB-C Hub'), qty: 2 },
            ]);

            console.log('✅ Orders seeded');
        } else {
            console.log('⚠️  Skipping comments/orders — could not find admin or testuser.');
        }

        console.log('✅ Database seeding complete!');

        await app.close();
        process.exit(0);
    } catch (error) {
        console.error('\n❌ Error seeding database:', error.message);
        console.error('Details:', error);
        process.exit(1);
    }
}

seed();
