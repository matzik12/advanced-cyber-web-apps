import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Product } from './product.entity';

@Injectable()
export class ProductsService {
    constructor(
        @InjectRepository(Product)
        private productsRepository: Repository<Product>,
    ) { }

    async findAll(): Promise<Product[]> {
        return this.productsRepository.find();
    }

    async findById(id: string): Promise<Product | null> {
        return this.productsRepository.findOne({ where: { id } });
    }

    async create(productData: Partial<Product>): Promise<Product> {
        const product = this.productsRepository.create(productData);
        return this.productsRepository.save(product);
    }

    async delete(id: string): Promise<void> {
        await this.productsRepository.delete(id);
    }

    // TODO: Add search functionality with SQL injection vulnerability
    // TODO: Add product reviews with XSS vulnerability
}
