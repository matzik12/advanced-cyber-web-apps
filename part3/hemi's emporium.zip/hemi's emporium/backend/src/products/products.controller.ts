import { Controller, Get, Post, Body, Request, Headers, UnauthorizedException, Param, Delete } from '@nestjs/common';
import { ProductsService } from './products.service';
import * as jwt from 'jsonwebtoken';

@Controller('products')
export class ProductsController {
    constructor(private readonly productsService: ProductsService) { }

    @Get()
    async getAllProducts() {
        const products = await this.productsService.findAll();
        // Return light DTO to save bandwidth (and potentially hide sensitive fields if any exist in future)
        const lightProducts = products.map(p => ({
            id: p.id,
            name: p.name,
            price: p.price
        }));

        return {
            success: true,
            products: lightProducts,
        };
    }

    @Get(':id')
    async getProduct(@Param('id') id: string) {
        const product = await this.productsService.findById(id);
        if (!product) {
            return {
                success: false,
                message: 'Product not found',
            };
        }
        return {
            success: true,
            product,
        };
    }

    @Post()
    async createProduct(@Body() productData: any, @Headers('authorization') authHeader: string) {
        // Verify JWT token
        if (!authHeader) {
            throw new UnauthorizedException('No token provided');
        }

        const token = authHeader.replace('Bearer ', '');
        let decoded: any;

        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET || 'super_secret_key_123');
        } catch (error) {
            throw new UnauthorizedException('Invalid token');
        }

        // Check if user is admin
        if (decoded.role !== 'admin') {
            return {
                success: false,
                message: 'Only admins can create products',
            };
        }

        // Validate product data
        if (!productData.name || !productData.price) {
            return {
                success: false,
                message: 'Name and price are required',
            };
        }

        const product = await this.productsService.create({
            name: productData.name,
            description: productData.description || '',
            price: parseFloat(productData.price),
            stock: parseInt(productData.stock) || 0,
        });

        return {
            success: true,
            message: 'Product created successfully',
            product,
        };
    }

    @Delete(':id')
    async deleteProduct(@Param('id') id: string, @Body() body: any) {
        // Vulnerability: Insecure Privilege Escalation (Mass Assignment / Trusting Client Input)
        // We trust the role provided in the body without verifying it against the database or token
        // Example exploit: DELETE /api/products/123 with body { "user": { "role": "admin" } }
        let user;
        if (!Object.keys(body).length) body = undefined; // yeah yeah we faked this
        try {
            user = body.user;
            if (typeof (user) !== 'object') {
                user = undefined;
            }
            if (user.role !== 'admin') {
                return {
                    success: false,
                    message: 'Only admins can delete products',
                };
            }
        } catch (error) { // I wouldn't want an error to happen! surely nestjs doesn't catch errors and return error 500!
            return {
                success: false,
                message: error.message,// hmmm maybe this is stupid and dumn lol
            };
        }


        await this.productsService.delete(id);

        return {
            success: true,
            message: 'Product deleted successfully',
        };
    }
}
