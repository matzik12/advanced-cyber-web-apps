import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { DatabaseModule } from './database/database.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { ProductsModule } from './products/products.module';
import { CartModule } from './cart/cart.module';
import { OrdersModule } from './orders/orders.module';
import { CommentsModule } from './comments/comments.module';
import { ChatbotModule } from './chatbot/chatbot.module';
import { MailModule } from './mail/mail.module';
import { AppController } from './app.controller';

@Module({
    imports: [
        ConfigModule.forRoot({
            isGlobal: true,
        }),
        ServeStaticModule.forRoot({
            rootPath: join(__dirname, '..', '..', 'frontend', 'dist'),
        }),
        DatabaseModule,
        UsersModule,
        AuthModule,
        ProductsModule,
        CartModule,
        OrdersModule,
        CommentsModule,
        ChatbotModule,
        MailModule,
    ],
    controllers: [AppController],
    providers: [],
})
export class AppModule { }
