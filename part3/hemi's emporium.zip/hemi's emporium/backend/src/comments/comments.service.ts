import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Comment } from './comment.entity';

@Injectable()
export class CommentsService {
    constructor(
        @InjectRepository(Comment)
        private commentsRepository: Repository<Comment>,
    ) { }

    async createComment(productId: string, userId: string, username: string, content: string): Promise<Comment> {
        // VULNERABILITY: Store without sanitization
        const comment = this.commentsRepository.create({
            productId,
            userId,
            username,
            content,
        });

        return await this.commentsRepository.save(comment);
    }

    async getCommentsByProduct(productId: string): Promise<Comment[]> {
        return this.commentsRepository.find({
            where: { productId },
            order: { createdAt: 'DESC' },
        });
    }
}
