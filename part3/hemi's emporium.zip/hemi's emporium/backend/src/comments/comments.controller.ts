import { Controller, Post, Get, Body, Param, Headers, UnauthorizedException } from '@nestjs/common';
import { CommentsService } from './comments.service';
import * as jwt from 'jsonwebtoken';

@Controller('comments')
export class CommentsController {
    constructor(private commentsService: CommentsService) { }

    @Post()
    async createComment(
        @Headers('authorization') authHeader: string,
        @Body() body: { productId: string; content: string },
    ) {
        try {
            if (!authHeader) {
                throw new UnauthorizedException('No authorization header');
            }

            const token = authHeader.replace('Bearer ', '');
            const secret = process.env.JWT_SECRET || 'super_secret_key_123';
            const decoded: any = jwt.verify(token, secret);

            const { productId, content } = body;

            if (!productId || !content) {
                return {
                    success: false,
                    message: 'Product ID and content are required',
                };
            }

            const comment = await this.commentsService.createComment(
                productId,
                decoded.sub,
                decoded.username,
                content,
            );

            return {
                success: true,
                message: 'Comment added successfully',
                comment,
            };
        } catch (error) {
            return {
                success: false,
                message: 'Failed to add comment',
                error: error.message,
            };
        }
    }

    @Get(':productId')
    async getComments(@Param('productId') productId: string) {
        try {
            const comments = await this.commentsService.getCommentsByProduct(productId);
            return {
                success: true,
                comments,
            };
        } catch (error) {
            return {
                success: false,
                message: 'Failed to fetch comments',
                error: error.message,
            };
        }
    }
}
