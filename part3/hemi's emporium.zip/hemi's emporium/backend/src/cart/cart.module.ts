import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CartItem } from './cart-item.entity';
import { CartService } from './cart.service';
import { CartController } from './cart.controller';
import { UsersModule } from '../users/users.module';
import { OrdersModule } from '../orders/orders.module';

@Module({
    imports: [
        TypeOrmModule.forFeature([CartItem]),
        UsersModule,
        OrdersModule,
    ],
    providers: [CartService],
    controllers: [CartController],
    exports: [CartService],
})
export class CartModule { }
