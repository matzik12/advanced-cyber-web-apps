import { Controller, Get, Post, Delete, Body, Headers, Param } from '@nestjs/common';
import { CartService } from './cart.service';
import * as jwt from 'jsonwebtoken';

@Controller('cart')
export class CartController {
    constructor(private cartService: CartService) { }

    private getUserIdFromToken(authHeader: string): string | null {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) return null;

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );
            return decoded.sub;
        } catch (error) {
            return null;
        }
    }

    @Get()
    async getCart(@Headers('authorization') authHeader: string) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const cartItems = await this.cartService.getCartItems(userId);
        return {
            success: true,
            cart: cartItems,
        };
    }

    @Post()
    async addToCart(
        @Headers('authorization') authHeader: string,
        @Body() body: { productId: string; quantity?: number },
    ) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const cartItem = await this.cartService.addToCart(
            userId,
            body.productId,
            body.quantity || 1,
        );

        return {
            success: true,
            cartItem,
        };
    }

    @Delete(':productId')
    async removeFromCart(
        @Headers('authorization') authHeader: string,
        @Param('productId') productId: string,
    ) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        await this.cartService.removeFromCart(userId, productId);
        return {
            success: true,
            message: 'Item removed from cart',
        };
    }

    @Delete()
    async clearCart(@Headers('authorization') authHeader: string) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        await this.cartService.clearCart(userId);
        return {
            success: true,
            message: 'Cart cleared',
        };
    }

    @Post('checkout')
    async checkout(@Headers('authorization') authHeader: string) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        try {
            const result = await this.cartService.checkout(userId);
            return result;
        } catch (error) {
            return {
                success: false,
                message: error.message || 'Checkout failed',
            };
        }
    }
}
