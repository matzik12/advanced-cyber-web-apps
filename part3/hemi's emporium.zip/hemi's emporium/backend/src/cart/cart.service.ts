import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CartItem } from './cart-item.entity';
import { UsersService } from '../users/users.service';
import { OrdersService } from '../orders/orders.service';

@Injectable()
export class CartService {
    constructor(
        @InjectRepository(CartItem)
        private cartItemsRepository: Repository<CartItem>,
        private usersService: UsersService,
        private ordersService: OrdersService,
    ) { }

    async getCartItems(userId: string): Promise<CartItem[]> {
        return this.cartItemsRepository.find({
            where: { userId },
            relations: ['product'],
        });
    }

    async addToCart(userId: string, productId: string, quantity: number = 1): Promise<CartItem> {
        // Check if item already exists in cart
        const existingItem = await this.cartItemsRepository.findOne({
            where: { userId, productId },
        });

        if (existingItem) {
            // Update quantity
            existingItem.quantity += quantity;
            return this.cartItemsRepository.save(existingItem);
        }

        // Create new cart item
        const cartItem = this.cartItemsRepository.create({
            userId,
            productId,
            quantity,
        });

        return this.cartItemsRepository.save(cartItem);
    }

    async removeFromCart(userId: string, productId: string): Promise<void> {
        const cartItem = await this.cartItemsRepository.findOne({
            where: { userId, productId },
        });

        if (cartItem) {
            if (cartItem.quantity > 1) {
                cartItem.quantity -= 1;
                await this.cartItemsRepository.save(cartItem);
            } else {
                await this.cartItemsRepository.remove(cartItem);
            }
        }
    }

    async clearCart(userId: string): Promise<void> {
        await this.cartItemsRepository.delete({ userId });
    }

    async checkout(userId: string): Promise<any> {
        // Get cart items
        const cartItems = await this.getCartItems(userId);

        if (cartItems.length === 0) {
            return {
                success: false,
                message: 'Cart is empty',
            };
        }

        // Calculate total
        const total = cartItems.reduce((sum, item) => {
            return sum + (Number(item.product.price) * item.quantity);
        }, 0);

        // Get user balance
        const user = await this.usersService.findById(userId);
        if (!user) {
            return {
                success: false,
                message: 'User not found',
            };
        }

        const userBalance = Number(user.balance) || 0;

        // Check if user has enough funds
        if (userBalance < total) {
            return {
                success: false,
                message: `Insufficient funds. You need $${total.toFixed(2)} but only have $${userBalance.toFixed(2)}`,
                required: total,
                available: userBalance,
            };
        }

        // Deduct balance
        const newBalance = userBalance - total;
        await this.usersService.updateBalance(userId, newBalance);

        // Create order
        const orderItems = cartItems.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
            price: Number(item.product.price),
        }));

        const order = await this.ordersService.createOrder(userId, total, orderItems);

        // Clear cart
        await this.clearCart(userId);

        return {
            success: true,
            message: 'Checkout successful!',
            orderId: order.id,
            total,
            newBalance,
        };
    }
}
