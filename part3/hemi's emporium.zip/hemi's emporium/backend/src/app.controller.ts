import { Controller, Get, Req, Res, Next } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { join } from 'path';

/**
 * Fallback controller to handle React Router routes.
 * With global API prefix (/api/*), this is much simpler:
 * - Requests with file extensions → static assets
 * - Requests to /api/* → API controllers
 * - Everything else → SPA navigation (serve index.html)
 */
@Controller()
export class AppController {
    @Get('*')
    serveFrontend(@Req() req: Request, @Res() res: Response, @Next() next: NextFunction) {
        const path = req.path;

        // If the request has a file extension, it's a static asset
        if (path.includes('.')) {
            return next();
        }

        // If it's an API request (all API routes are under /api), pass to controllers
        if (path.startsWith('/api')) {
            return next();
        }

        // Otherwise, it's a SPA navigation route - serve index.html
        res.sendFile(join(__dirname, '..', '..', 'frontend', 'dist', 'index.html'));
    }
}
