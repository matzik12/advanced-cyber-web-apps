import { Controller, Post, Body, Get, Headers } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto, RegisterDto } from './dto/auth.dto';
import * as jwt from 'jsonwebtoken';

@Controller('auth')
export class AuthController {
    constructor(private authService: AuthService) { }

    @Post('login')
    async login(@Body() loginDto: LoginDto) {
        return this.authService.login(loginDto);
    }

    @Post('register')
    async register(@Body() registerDto: RegisterDto) {
        return this.authService.register(registerDto);
    }

    @Get('vulnerabilities')
    async getVulnerabilities(@Headers('authorization') authHeader: string) {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) {
                return { success: false, message: 'No token provided' };
            }

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );
            const vulnerabilities = await this.authService.getVulnerabilities(decoded.sub);

            return {
                success: true,
                vulnerabilities,
            };
        } catch (error) {
            return { success: false, message: 'Invalid token' };
        }
    }

    @Get('verify')
    async verifyToken(@Headers('authorization') authHeader: string) {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) {
                return { success: false, message: 'No token provided' };
            }

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );

            // Get user info
            const user = await this.authService.getUserById(decoded.sub);
            if (!user) {
                return { success: false, message: 'User not found' };
            }

            return {
                success: true,
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    isAdmin: user.isAdmin,
                    imageUrl: (user as any).imageUrl || null,
                    imageData: (user as any).imageData || null,
                },
            };
        } catch (error) {
            return { success: false, message: 'Invalid or expired token' };
        }
    }

    // VULNERABILITY: no rate limiting — anyone can flood this endpoint
    @Post('reset-request')
    async requestPasswordReset(@Body() body: { email: string }) {
        return this.authService.requestPasswordReset(body.email);
    }

    // VULNERABILITY: token not invalidated after use — can reset password multiple times with same token
    @Post('reset-password')
    async resetPassword(@Body() body: { token: string; newPassword: string }) {
        return this.authService.resetPassword(body.token, body.newPassword);
    }
}
