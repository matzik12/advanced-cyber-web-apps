export class LoginDto {
    username: string;
    password: string;
}

export class RegisterDto {
    username: string;
    password: string;
    confirmPassword: string;
    email?: string;
}

export interface UserDto {
    id: string;
    username: string;
    email?: string;
    role?: string;
    imageUrl?: string;
    imageData?: string;
}

export class LoginResponseDto {
    success: boolean;
    message: string;
    token?: string;
    user?: UserDto;
    vulnerabilityDetected?: {
        name: string;
        description: string;
        congratulations: string;
    };
}
