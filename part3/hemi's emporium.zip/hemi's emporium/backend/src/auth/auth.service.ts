import { Injectable } from '@nestjs/common';
import { UsersService } from '../users/users.service';
import { LoginDto, RegisterDto, LoginResponseDto } from './dto/auth.dto';
import * as jwt from 'jsonwebtoken';
import { Secret, SignOptions } from 'jsonwebtoken';
import { MailService } from '../mail/mail.service';

@Injectable()
export class AuthService {
    constructor(
        private usersService: UsersService,
        private mailService: MailService,
    ) { }

    async login(loginDto: LoginDto): Promise<LoginResponseDto> {
        const { username, password } = loginDto;

        // VULNERABILITY DETECTION: Check for SQL injection attempts
        const sqlInjectionPatterns = [
            /'\s*OR\s*'1'\s*=\s*'1/i,
            /'\s*OR\s*1\s*=\s*1/i,
            /--/,
            /;\s*DROP/i,
            /UNION.*SELECT/i,
        ];

        const isSqlInjection = sqlInjectionPatterns.some(pattern =>
            pattern.test(username) || pattern.test(password)
        );

        // Use the vulnerable query
        const user = await this.usersService.findByUsername(username);

        // If SQL injection detected and user found (bypass succeeded)
        if (isSqlInjection && user) {
            const token = this.generateToken(user);

            return {
                success: true,
                message: 'Login successful',
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    imageUrl: (user as any).imageUrl || null,
                    imageData: (user as any).imageData || null,
                },
                vulnerabilityDetected: {
                    name: 'SQL Injection',
                    description: 'You successfully exploited SQL injection in the login form!',
                    congratulations: '🎉 Vulnerability discovered: SQL Injection! The login query was vulnerable to SQL injection attacks.',
                },
            };
        }

        // Normal authentication flow
        if (!user) {
            return {
                success: false,
                message: 'Invalid username or password',
            };
        }

        // VULNERABILITY: Plain text password comparison
        if (user.password !== password) {
            return {
                success: false,
                message: 'Invalid username or password',
            };
        }

        const token = this.generateToken(user);

        return {
            success: true,
            message: 'Login successful',
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                imageUrl: (user as any).imageUrl || null,
                imageData: (user as any).imageData || null,
            },
        };
    }

    async register(registerDto: RegisterDto): Promise<LoginResponseDto> {
        const { username, password, confirmPassword, email } = registerDto;

        // VULNERABILITY: Weak password validation
        if (!username || !password) {
            return {
                success: false,
                message: 'Username and password are required',
            };
        }

        if (password !== confirmPassword) {
            return {
                success: false,
                message: 'Passwords do not match',
            };
        }

        // Enforce local mail domain — all emails go to MailHog (localhost:8025)
        if (email && !email.endsWith('@hemi-emporium.local')) {
            return {
                success: false,
                message: 'Email must be a @hemi-emporium.local address. Use the MailHog inbox at http://localhost:8025.',
            };
        }

        // Check if username already exists
        const existingUser = await this.usersService.findByUsername(username);
        if (existingUser) {
            return {
                success: false,
                message: 'Username already exists',
            };
        }

        // VULNERABILITY: No password strength requirements
        // VULNERABILITY: Password stored in plaintext
        const user = await this.usersService.create({
            username,
            password, // Stored in plaintext!
            email,
            isAdmin: false,
        });

        const token = this.generateToken(user);

        return {
            success: true,
            message: 'Registration successful',
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
            },
        };
    }

    private generateToken(user: any): string {
        // VULNERABILITY: Weak JWT secret (configured in .env)
        const payload = {
            sub: user.id,
            username: user.username,
            role: user.role || 'user',
            isAdmin: user.isAdmin,
        };

        const secret: Secret = process.env.JWT_SECRET || 'super_secret_key_123';

        const options: SignOptions = {
            expiresIn: (process.env.JWT_EXPIRES_IN as any) || '1d',
        };

        return jwt.sign(payload, secret, options);
    }

    async getVulnerabilities(userId: string): Promise<string[]> {
        // Vulnerabilities are now tracked client-side in localStorage
        return [];
    }

    async getUserById(userId: string) {
        return this.usersService.findById(userId);
    }

    // ---------------------------------------------------------------
    // PASSWORD RESET — intentionally vulnerable
    // VULNERABILITY #2: token is NOT invalidated after use (usable multiple times)
    // VULNERABILITY #3: token has NO expiry — valid forever
    // VULNERABILITY #6: no rate limiting (nothing stops flooding reset requests)
    // ---------------------------------------------------------------

    // In-memory store: token → userId
    // Tokens are never deleted, so they work forever and even after being "used"
    private resetTokens = new Map<string, string>();

    // Tracks tokens that have already been used once (to detect reuse attempts)
    private usedTokens = new Set<string>();

    async requestPasswordReset(email: string): Promise<{ success: boolean; message: string }> {
        const user = await this.usersService.findByEmail(email);

        // Generic response to avoid email enumeration (unlike the previous version)
        // Even if user doesn't exist we return the same message
        if (!user) {
            return { success: false, message: 'No account found with that email address.' };
        }

        // VULNERABILITY #1 (Weak Token): token is timestamp-based — easily guessable
        // Format: base36(Date.now()) + base36(small random) → e.g. "lkv2abc3f"
        // The timestamp portion narrows the search space to ~milliseconds around the request
        const tsComponent = Date.now().toString(36);          // ~8 chars, fully predictable
        const randComponent = Math.floor(Math.random() * 100).toString(36); // 1-2 chars, tiny
        const token = tsComponent + randComponent;

        // VULNERABILITY #3 (No expiry): stored forever, never pruned
        // VULNERABILITY #6 (No rate limit): nothing throttles calls to this endpoint
        this.resetTokens.set(token, user.id);

        // Send the token via email (goes to MailHog internally, not accessible by students)
        try {
            await this.mailService.sendPasswordResetEmail(user.email, token);
        } catch (err) {
            console.error('Failed to send reset email:', err);
            return { success: false, message: 'Failed to send reset email. Please try again.' };
        }

        return {
            success: true,
            message: 'A reset token has been sent to your email address.',
        };
    }

    async resetPassword(token: string, newPassword: string): Promise<{ success: boolean; message: string; isAdminReset?: boolean; tokenWasPreviouslyUsed?: boolean }> {
        const userId = this.resetTokens.get(token);

        if (!userId) {
            return { success: false, message: 'Invalid reset token' };
        }

        // Was this token already used before?
        const tokenWasPreviouslyUsed = this.usedTokens.has(token);

        // VULNERABILITY #2: token is NOT removed after use — mark as used but keep it valid
        // this.resetTokens.delete(token);  <-- intentionally commented out
        this.usedTokens.add(token);

        const user = await this.usersService.findById(userId);
        const isAdminReset = user?.role === 'admin';

        await this.usersService.updatePassword(userId, newPassword);

        return {
            success: true,
            message: 'Password reset successful',
            isAdminReset,
            tokenWasPreviouslyUsed,
        };
    }
}
