import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { AppController } from './app.controller';
import { RequestMethod } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Set global API prefix - all routes will be under /api/* EXCEPT AppController
  app.setGlobalPrefix('api', {
    exclude: [{ path: '*', method: RequestMethod.GET }],
  });

  // VULNERABILITY: Overly permissive CORS configuration
  app.enableCors({
    origin: '*', // Allow all origins (not recommended for production)
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });

  const port = process.env.PORT || 3001;
  await app.listen(port);

  console.log(`
  ╔═══════════════════════════════════════════════════════════════╗
  ║                                                                 ║
  ║   🔒 Vulnerable Store Backend - Educational Version 🔒         ║
  ║                                                                 ║
  ║   Server running on: http://localhost:${port}                    ║
  ║                                                                 ║
  ║   ⚠️  WARNING: This application contains intentional           ║
  ║   security vulnerabilities for educational purposes.           ║
  ║   DO NOT deploy to production!                                 ║
  ║                                                                 ║
  ║   Available Endpoints:                                          ║
  ║   • POST /auth/login - User login                              ║
  ║   • POST /auth/register - User registration                    ║
  ║   • GET /auth/vulnerabilities - View found vulnerabilities     ║
  ║                                                                 ║
  ║   Try to find and exploit the vulnerabilities! 🕵️              ║
  ║                                                                 ║
  ╚═══════════════════════════════════════════════════════════════╝
  `);
}

bootstrap();
