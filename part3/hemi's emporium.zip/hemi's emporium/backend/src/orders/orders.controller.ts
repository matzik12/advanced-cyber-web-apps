import { Body, Controller, Get, Headers, Param, Post } from '@nestjs/common';
import { OrdersService } from './orders.service';
import * as jwt from 'jsonwebtoken';

@Controller('orders')
export class OrdersController {
    constructor(private ordersService: OrdersService) { }

    private getUserIdFromToken(authHeader: string): string | null {
        try {
            const token = authHeader?.replace('Bearer ', '');
            if (!token) return null;

            const decoded: any = jwt.verify(
                token,
                process.env.JWT_SECRET || 'super_secret_key_123',
            );
            return decoded.sub;
        } catch (error) {
            return null;
        }
    }

    @Post()
    async getUserOrders(@Body() bodyData: any, @Headers('authorization') authHeader: string) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        // vulnerability: IDOR
        const orders = await this.ordersService.getUserOrders(bodyData.userId);

        // Fetch items for each order
        const ordersWithItems = await Promise.all(
            orders.map(async (order) => {
                const items = await this.ordersService.getOrderItems(order.id);
                return { ...order, items };
            })
        );

        return {
            success: true,
            orders: ordersWithItems,
        };
    }

    @Get(':orderId/items')
    async getOrderItems(
        @Body() bodyData: any,
        @Headers('authorization') authHeader: string,
        @Param('orderId') orderId: string,
    ) {
        const userId = this.getUserIdFromToken(authHeader);
        if (!userId) {
            return { success: false, message: 'Unauthorized' };
        }

        const items = await this.ordersService.getOrderItems(orderId);
        return {
            success: true,
            items,
        };
    }
}
