import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order } from './order.entity';
import { OrderItem } from './order-item.entity';

@Injectable()
export class OrdersService {
    constructor(
        @InjectRepository(Order)
        private ordersRepository: Repository<Order>,
        @InjectRepository(OrderItem)
        private orderItemsRepository: Repository<OrderItem>,
    ) { }

    async createOrder(userId: string, total: number, items: { productId: string; quantity: number; price: number }[]): Promise<Order> {
        // Create order
        const order = this.ordersRepository.create({
            userId,
            total,
            status: 'completed',
        });
        await this.ordersRepository.save(order);

        // Create order items
        for (const item of items) {
            const orderItem = this.orderItemsRepository.create({
                orderId: order.id,
                productId: item.productId,
                quantity: item.quantity,
                price: item.price,
            });
            await this.orderItemsRepository.save(orderItem);
        }

        return order;
    }

    async getUserOrders(userId: string): Promise<Order[]> {
        return this.ordersRepository.find({
            where: { userId },
            order: { createdAt: 'DESC' },
        });
    }

    async getOrderItems(orderId: string): Promise<OrderItem[]> {
        return this.orderItemsRepository.find({
            where: { orderId },
            relations: ['product'],
        });
    }
}
