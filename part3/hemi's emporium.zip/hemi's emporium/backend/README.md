# Backend — NestJS API 🔒

NestJS backend for Hemi's Emporium. Serves both the REST API (under `/api/*`) and the pre-built React frontend as static files.

> ⚠️ Intentionally vulnerable for educational purposes — see the [root README](../README.md) for the full vulnerability list.

---

## Running

### Via Docker (recommended)

From the `backend/` directory:

```bash
docker compose up -d          # start all services
docker compose up -d --build  # rebuild and restart after code changes
```

The backend container waits for PostgreSQL to be healthy before starting.

### Local dev (hot-reload)

Requires postgres/mailhog/ollama already running in Docker:

```bash
npm install
npm run start:dev   # http://localhost:3001
```

---

## Environment Variables

| Variable | Local (`.env`) | Docker (`.env.docker`) |
|---|---|---|
| `DB_HOST` | `localhost` | `postgres` |
| `DB_PORT` | `5433` | `5432` |
| `MAILHOG_HOST` | `127.0.0.1` | `mailhog` |
| `OLLAMA_URL` | `http://localhost:11434` | `http://ollama:11434` |
| `PORT` | `3001` | `3001` |
| `JWT_SECRET` | `super_secret_key_123` | same |

Copy `.env.example` to `.env` for local dev:

```bash
cp .env.example .env
```

---

## Scripts

| Command | Description |
|---|---|
| `npm run start:dev` | Hot-reload dev server |
| `npm run start:prod` | Run compiled production build |
| `npm run build` | Compile TypeScript → `dist/` |
| `npm run seed` | Clear DB and insert fresh seed data |

---

## Seeding

```bash
# Docker
docker compose exec backend npm run seed

# Local
npm run seed
```

Inserts: 2 users · 11 products · 7 comments · 4 orders with items.

> ⚠️ Seed clears **all existing data** before inserting.

---

## Project Structure

```
backend/
├── src/
│   ├── auth/           # Auth endpoints, JWT, password reset
│   ├── users/          # User entity + service (SQL injection lives here)
│   ├── products/       # Product catalog
│   ├── cart/           # Shopping cart
│   ├── orders/         # Order processing
│   ├── comments/       # Product comments (XSS vulnerability)
│   ├── chatbot/        # Ollama LLM proxy (prompt injection vulnerability)
│   ├── mail/           # MailHog SMTP integration
│   ├── database/       # TypeORM + ConfigService setup
│   ├── app.module.ts   # Root module (ServeStaticModule for frontend)
│   ├── main.ts         # Entry point
│   └── seed.ts         # Database seed script
├── Dockerfile          # Multi-stage: frontend + backend build → runner
├── .dockerignore
├── docker-compose.yml  # All services: postgres, ollama, mailhog, backend
├── .env                # Local dev (gitignored)
├── .env.docker         # Docker-internal env (service hostnames)
├── .env.example        # Template
└── package.json
```

---

## API Endpoints (summary)

All routes are prefixed with `/api`.

| Method | Path | Description |
|---|---|---|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Login (SQL injectable) |
| POST | `/api/auth/request-password-reset` | Send reset email |
| POST | `/api/auth/reset-password` | Reset password with token |
| GET | `/api/products` | List products |
| GET | `/api/products/:id` | Get product detail |
| GET/POST/DELETE | `/api/cart` | Manage cart |
| POST | `/api/orders` | Place order |
| GET | `/api/orders` | Get user orders |
| GET | `/api/orders/:id` | Get order (IDOR vulnerable) |
| GET/POST/DELETE | `/api/comments` | Product comments (XSS) |
| POST | `/api/chatbot` | Chat with LLM (prompt injection) |
| GET/POST/DELETE | `/api/admin/*` | Admin-only routes |
